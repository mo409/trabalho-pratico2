java -cp "randoop-all-4.2.6.jar:randoop.main.Main:lib/commons-collections4-4.4.jar:lib/mo409-1.0-SNAPSHOT.jar" randoop.main.Main gentests --classlist=classes.txt  --usethreads=true --log=filename.log
