import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.Class<?> wildcardClass1 = strComparableCollection0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean2 = strComparableCollection0.remove((java.lang.Object) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        java.util.Collection<java.lang.Comparable<java.lang.String>> strComparableCollection6 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = strComparableCollection0.containsAll(strComparableCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        java.lang.Object[] objArray4 = strComparableCollection2.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator5 = strComparableCollection2.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean6 = strComparableCollection0.remove((java.lang.Object) strComparableCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray4), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray4), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean5 = strComparableCollection0.remove((java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.Class<?> wildcardClass4 = strComparableCollection0.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.Collection<java.lang.Comparable<java.lang.String>> strComparableCollection3 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = strComparableCollection0.removeAll(strComparableCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.lang.Class<?> wildcardClass22 = strComparableCollectionArray21.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        boolean boolean24 = strComparableCollection22.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream25 = strComparableCollection22.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean26 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strComparableStream25);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        // The following exception was thrown during execution in test generation
        try {
            int int6 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean5 = strComparableCollection0.remove((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        boolean boolean25 = strComparableCollection22.equals((java.lang.Object) 1.0d);
        int int26 = strComparableCollection22.size();
        java.lang.String str27 = strComparableCollection22.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean28 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection22);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "[]" + "'", str27, "[]");
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int6 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean5 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        // The following exception was thrown during execution in test generation
        try {
            int int8 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        java.lang.Class<?> wildcardClass4 = strComparableCollection0.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        boolean boolean11 = strComparableCollection6.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            int int14 = strComparableCollection6.add((java.lang.Comparable<java.lang.String>) "[]", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        boolean boolean11 = strComparableCollection6.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = strComparableCollection6.remove((java.lang.Object) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList3 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean5 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean6 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream7 = strComparableList3.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableList3.spliterator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strComparableStream7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = strComparableCollection0.remove((java.lang.Object) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean5 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.stream.BaseStream<java.lang.Comparable<java.lang.String>, java.util.stream.Stream<java.lang.Comparable<java.lang.String>>>> strComparableBaseStreamCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.stream.BaseStream<java.lang.Comparable<java.lang.String>, java.util.stream.Stream<java.lang.Comparable<java.lang.String>>>>();
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet7 = strComparableCollection0.entrySet();
        // The following exception was thrown during execution in test generation
        try {
            int int10 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableEntrySet7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableSet8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.AutoCloseable> autoCloseableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.AutoCloseable>();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            int int5 = strComparableCollection0.remove((java.lang.Object) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean33 = strComparableCollection0.remove((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            int int6 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.util.AbstractList[] abstractListArray5 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray6 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray5;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray7 = strComparableCollection0.toArray(strComparableListArray6);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean9 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(abstractListArray5);
        org.junit.Assert.assertNotNull(strComparableListArray6);
        org.junit.Assert.assertNotNull(strComparableListArray7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.lang.Class<?> wildcardClass7 = strComparableCollection0.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.parallelStream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean6 = strComparableCollection4.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor8 = strComparableCollection0.iterator();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strComparableItor8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass1 = strComparableListCollection0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray24 = strComparableCollection17.toArray((java.lang.Comparable<java.lang.String>[]) strArray23);
        java.lang.CharSequence[] charSequenceArray25 = strComparableCollection8.toArray((java.lang.CharSequence[]) strArray23);
        boolean boolean26 = strComparableCollection0.equals((java.lang.Object) strComparableCollection8);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor27 = strComparableCollection8.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean29 = strComparableCollection8.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(charSequenceArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strComparableItor27);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean5 = strComparableCollection0.remove((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int9 = strComparableCollection0.getCount((java.lang.Object) 0L);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray24 = strComparableCollection17.toArray((java.lang.Comparable<java.lang.String>[]) strArray23);
        java.lang.CharSequence[] charSequenceArray25 = strComparableCollection8.toArray((java.lang.CharSequence[]) strArray23);
        boolean boolean26 = strComparableCollection0.equals((java.lang.Object) strComparableCollection8);
        int int27 = strComparableCollection8.size();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(charSequenceArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator4 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection5.spliterator();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray12 = strComparableCollection5.toArray((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection5.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean14 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableSpliterator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strComparableItor13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean6 = strComparableCollection0.remove((java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableStream4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean31 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet9 = strComparableCollection6.uniqueSet();
        boolean boolean10 = strComparableCollection0.contains((java.lang.Object) strComparableCollection6);
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean2 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray24 = strComparableCollection17.toArray((java.lang.Comparable<java.lang.String>[]) strArray23);
        java.lang.CharSequence[] charSequenceArray25 = strComparableCollection8.toArray((java.lang.CharSequence[]) strArray23);
        boolean boolean26 = strComparableCollection0.equals((java.lang.Object) strComparableCollection8);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor27 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection28 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str29 = strComparableCollection28.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection30 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean31 = strComparableCollection30.isEmpty();
        boolean boolean33 = strComparableCollection30.equals((java.lang.Object) 1.0d);
        boolean boolean35 = strComparableCollection30.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection36 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean37 = strComparableCollection36.isEmpty();
        boolean boolean39 = strComparableCollection36.equals((java.lang.Object) 1.0d);
        int int40 = strComparableCollection36.size();
        java.lang.String str41 = strComparableCollection36.toString();
        java.util.Collection[] collectionArray43 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray44 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray43;
        strComparableCollectionArray44[0] = strComparableCollection30;
        strComparableCollectionArray44[1] = strComparableCollection36;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray49 = strComparableCollection28.toArray(strComparableCollectionArray44);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean50 = strComparableCollection8.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(charSequenceArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strComparableItor27);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "[]" + "'", str29, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "[]" + "'", str41, "[]");
        org.junit.Assert.assertNotNull(collectionArray43);
        org.junit.Assert.assertNotNull(strComparableCollectionArray44);
        org.junit.Assert.assertNotNull(strComparableCollectionArray49);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Collection[] collectionArray7 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray8 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray7;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = strComparableCollection3.toArray(strComparableCollectionArray8);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(collectionArray7);
        org.junit.Assert.assertNotNull(strComparableCollectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.Type[]> typeArrayCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.Type[]>();
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str8 = strComparableCollection7.toString();
        java.lang.Object[] objArray9 = strComparableCollection7.toArray();
        java.util.Collection[] collectionArray11 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray12 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray11;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray13 = strComparableCollection7.toArray(strComparableCollectionArray12);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet14 = strComparableCollection7.entrySet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet15 = strComparableCollection7.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableSet15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
        org.junit.Assert.assertNotNull(collectionArray11);
        org.junit.Assert.assertNotNull(strComparableCollectionArray12);
        org.junit.Assert.assertNotNull(strComparableCollectionArray13);
        org.junit.Assert.assertNotNull(strComparableEntrySet14);
        org.junit.Assert.assertNotNull(strComparableSet15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection23 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str24 = strComparableCollection23.toString();
        java.lang.Object[] objArray25 = strComparableCollection23.toArray();
        java.util.Collection[] collectionArray27 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray28 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray27;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection23.toArray(strComparableCollectionArray28);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor30 = strComparableCollection23.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean31 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray25), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray25), "[]");
        org.junit.Assert.assertNotNull(collectionArray27);
        org.junit.Assert.assertNotNull(strComparableCollectionArray28);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableItor30);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection14 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean15 = strComparableCollection14.isEmpty();
        boolean boolean16 = strComparableCollection14.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream17 = strComparableCollection14.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int19 = strComparableCollection0.remove((java.lang.Object) strComparableStream17, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strComparableStream17);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList3 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean5 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean6 = strComparableList3.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream7 = strComparableList3.parallelStream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream8 = strComparableList3.parallelStream();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strComparableStream7);
        org.junit.Assert.assertNotNull(strComparableStream8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet11 = strComparableCollection0.entrySet();
        java.lang.Class<?> wildcardClass12 = strComparableCollection0.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor32 = strComparableCollection0.iterator();
        // The following exception was thrown during execution in test generation
        try {
            int int35 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "[]", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableItor32);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList5 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableList5.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean7 = strComparableList5.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean8 = strComparableList5.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableList5.parallelStream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream10 = strComparableList5.parallelStream();
        java.util.RandomAccess[] randomAccessArray11 = new java.util.RandomAccess[] { strComparableList5 };
        java.util.RandomAccess[] randomAccessArray12 = strComparableCollection0.toArray(randomAccessArray11);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertNotNull(strComparableStream10);
        org.junit.Assert.assertNotNull(randomAccessArray11);
        org.junit.Assert.assertNotNull(randomAccessArray12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Collection[] collectionArray7 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray8 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray7;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = strComparableCollection3.toArray(strComparableCollectionArray8);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = strComparableCollection0.remove((java.lang.Object) strComparableCollectionArray8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(collectionArray7);
        org.junit.Assert.assertNotNull(strComparableCollectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection5.spliterator();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray12 = strComparableCollection5.toArray((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection5.iterator();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableItor13);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean18 = strComparableCollection16.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str20 = strComparableCollection19.toString();
        java.lang.Object[] objArray21 = strComparableCollection19.toArray();
        java.lang.Object[] objArray22 = strComparableCollection19.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection23 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str24 = strComparableCollection23.toString();
        java.lang.Object[] objArray25 = strComparableCollection23.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection26 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean27 = strComparableCollection26.isEmpty();
        java.lang.Object[] objArray28 = strComparableCollection26.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator29 = strComparableCollection26.spliterator();
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray33 = strComparableCollection26.toArray((java.lang.Comparable<java.lang.String>[]) strArray32);
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList37 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean38 = strComparableList37.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean39 = strComparableList37.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean40 = strComparableList37.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream41 = strComparableList37.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator42 = strComparableList37.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection43 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str44 = strComparableCollection43.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection45 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean46 = strComparableCollection45.isEmpty();
        boolean boolean48 = strComparableCollection45.equals((java.lang.Object) 1.0d);
        boolean boolean50 = strComparableCollection45.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection51 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean52 = strComparableCollection51.isEmpty();
        boolean boolean54 = strComparableCollection51.equals((java.lang.Object) 1.0d);
        int int55 = strComparableCollection51.size();
        java.lang.String str56 = strComparableCollection51.toString();
        java.util.Collection[] collectionArray58 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray59 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray58;
        strComparableCollectionArray59[0] = strComparableCollection45;
        strComparableCollectionArray59[1] = strComparableCollection51;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray64 = strComparableCollection43.toArray(strComparableCollectionArray59);
        java.lang.Cloneable[] cloneableArray65 = new java.lang.Cloneable[] { objArray22, objArray25, strComparableArray33, strComparableList37, strComparableCollectionArray59 };
        java.lang.Cloneable[] cloneableArray66 = strComparableCollection16.toArray(cloneableArray65);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean67 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strComparableItor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "[]" + "'", str20, "[]");
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray21), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray21), "[]");
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray22), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray22), "[]");
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray25), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray25), "[]");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator29);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(strComparableArray33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(strComparableStream41);
        org.junit.Assert.assertNotNull(strComparableSpliterator42);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "[]" + "'", str44, "[]");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertEquals("'" + str56 + "' != '" + "[]" + "'", str56, "[]");
        org.junit.Assert.assertNotNull(collectionArray58);
        org.junit.Assert.assertNotNull(strComparableCollectionArray59);
        org.junit.Assert.assertNotNull(strComparableCollectionArray64);
        org.junit.Assert.assertNotNull(cloneableArray65);
        org.junit.Assert.assertNotNull(cloneableArray66);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection32 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean33 = strComparableCollection32.isEmpty();
        boolean boolean35 = strComparableCollection32.equals((java.lang.Object) 1.0d);
        boolean boolean37 = strComparableCollection32.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection38 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean39 = strComparableCollection38.isEmpty();
        boolean boolean41 = strComparableCollection38.equals((java.lang.Object) 1.0d);
        boolean boolean43 = strComparableCollection38.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection44 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean45 = strComparableCollection44.isEmpty();
        java.lang.Object[] objArray46 = strComparableCollection44.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator47 = strComparableCollection44.spliterator();
        boolean boolean48 = strComparableCollection38.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection44);
        boolean boolean49 = strComparableCollection32.equals((java.lang.Object) boolean48);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection50 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean51 = strComparableCollection50.isEmpty();
        boolean boolean53 = strComparableCollection50.equals((java.lang.Object) 1.0d);
        boolean boolean55 = strComparableCollection50.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection56 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean57 = strComparableCollection56.isEmpty();
        java.lang.Object[] objArray58 = strComparableCollection56.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator59 = strComparableCollection56.spliterator();
        boolean boolean60 = strComparableCollection50.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection56);
        int int61 = strComparableCollection50.size();
        java.lang.String str62 = strComparableCollection50.toString();
        boolean boolean63 = strComparableCollection32.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection50);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean64 = strComparableCollection4.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray46), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray46), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray58), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray58), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertEquals("'" + str62 + "' != '" + "[]" + "'", str62, "[]");
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        // The following exception was thrown during execution in test generation
        try {
            int int35 = strComparableCollection8.add((java.lang.Comparable<java.lang.String>) "", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection0.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            int int14 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strComparableStream11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        java.lang.CharSequence[][] charSequenceArray32 = new java.lang.CharSequence[][] {};
        java.lang.CharSequence[][] charSequenceArray33 = strComparableCollection4.toArray(charSequenceArray32);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream34 = strComparableCollection4.stream();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
        org.junit.Assert.assertNotNull(strComparableStream34);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Collection[] collectionArray12 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray13 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray12;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray14 = strComparableCollection8.toArray(strComparableCollectionArray13);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection8.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        java.lang.Object[] objArray18 = strComparableCollection16.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator19 = strComparableCollection16.spliterator();
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray23 = strComparableCollection16.toArray((java.lang.Comparable<java.lang.String>[]) strArray22);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor24 = strComparableCollection16.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection25 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean26 = strComparableCollection25.isEmpty();
        java.lang.Object[] objArray27 = strComparableCollection25.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator28 = strComparableCollection25.spliterator();
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray32 = strComparableCollection25.toArray((java.lang.Comparable<java.lang.String>[]) strArray31);
        java.lang.CharSequence[] charSequenceArray33 = strComparableCollection16.toArray((java.lang.CharSequence[]) strArray31);
        boolean boolean34 = strComparableCollection8.equals((java.lang.Object) strComparableCollection16);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean35 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(collectionArray12);
        org.junit.Assert.assertNotNull(strComparableCollectionArray13);
        org.junit.Assert.assertNotNull(strComparableCollectionArray14);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray18), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray18), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator19);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(strComparableArray23);
        org.junit.Assert.assertNotNull(strComparableItor24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray27), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray27), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator28);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(strComparableArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet9 = strComparableCollection6.uniqueSet();
        boolean boolean10 = strComparableCollection0.contains((java.lang.Object) strComparableCollection6);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet11 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str13 = strComparableCollection12.toString();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Collection[] collectionArray16 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray17 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray18 = strComparableCollection12.toArray(strComparableCollectionArray17);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator19 = strComparableCollection12.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream20 = strComparableCollection12.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean21 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strComparableEntrySet11);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(collectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray17);
        org.junit.Assert.assertNotNull(strComparableCollectionArray18);
        org.junit.Assert.assertNotNull(strComparableSpliterator19);
        org.junit.Assert.assertNotNull(strComparableStream20);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        int int20 = strComparableCollection9.size();
        int int21 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor22 = strComparableCollection9.iterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(strComparableItor22);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        java.lang.Class<?> wildcardClass19 = strComparableCollection4.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean8 = strComparableCollection7.isEmpty();
        boolean boolean10 = strComparableCollection7.contains((java.lang.Object) 1);
        boolean boolean12 = strComparableCollection7.contains((java.lang.Object) "[]");
        java.lang.String str13 = strComparableCollection7.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection7.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.parallelStream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream5 = strComparableCollection0.stream();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(strComparableStream5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertNotNull(strComparableStream4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            int int6 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet9 = strComparableCollection6.uniqueSet();
        boolean boolean10 = strComparableCollection0.contains((java.lang.Object) strComparableCollection6);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection11 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean12 = strComparableCollection11.isEmpty();
        boolean boolean14 = strComparableCollection11.equals((java.lang.Object) 1.0d);
        boolean boolean16 = strComparableCollection11.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        boolean boolean21 = strComparableCollection11.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection17);
        boolean boolean22 = strComparableCollection17.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean23 = strComparableCollection6.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor8 = strComparableCollection0.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        boolean boolean18 = strComparableCollection15.equals((java.lang.Object) 1.0d);
        boolean boolean20 = strComparableCollection15.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        boolean boolean25 = strComparableCollection15.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection21);
        boolean boolean26 = strComparableCollection9.equals((java.lang.Object) boolean25);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection27 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean28 = strComparableCollection27.isEmpty();
        boolean boolean30 = strComparableCollection27.equals((java.lang.Object) 1.0d);
        boolean boolean32 = strComparableCollection27.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection33 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean34 = strComparableCollection33.isEmpty();
        java.lang.Object[] objArray35 = strComparableCollection33.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator36 = strComparableCollection33.spliterator();
        boolean boolean37 = strComparableCollection27.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection33);
        int int38 = strComparableCollection27.size();
        java.lang.String str39 = strComparableCollection27.toString();
        boolean boolean40 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection27);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean41 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strComparableItor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray35), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray35), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "[]" + "'", str39, "[]");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableCollection0.uniqueSet();
        java.lang.Class<?> wildcardClass9 = strComparableCollection0.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableSet8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str11 = strComparableCollection10.toString();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Collection[] collectionArray14 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray15 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray14;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = strComparableCollection10.toArray(strComparableCollectionArray15);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet17 = strComparableCollection10.entrySet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet18 = strComparableCollection10.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean19 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableSet18);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(collectionArray14);
        org.junit.Assert.assertNotNull(strComparableCollectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableEntrySet17);
        org.junit.Assert.assertNotNull(strComparableSet18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean5 = strComparableCollection0.equals((java.lang.Object) (byte) 0);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Collection[] collectionArray10 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray11 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray10;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray12 = strComparableCollection6.toArray(strComparableCollectionArray11);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection6.entrySet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet14 = strComparableCollection6.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean15 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(collectionArray10);
        org.junit.Assert.assertNotNull(strComparableCollectionArray11);
        org.junit.Assert.assertNotNull(strComparableCollectionArray12);
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertNotNull(strComparableSet14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        // The following exception was thrown during execution in test generation
        try {
            int int34 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "[]", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        boolean boolean13 = strComparableCollection8.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection14 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean15 = strComparableCollection14.isEmpty();
        java.lang.Object[] objArray16 = strComparableCollection14.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator17 = strComparableCollection14.spliterator();
        boolean boolean18 = strComparableCollection8.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection14);
        int int19 = strComparableCollection8.size();
        java.lang.String str20 = strComparableCollection8.toString();
        java.lang.Object[] objArray21 = strComparableCollection8.toArray();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean22 = strComparableCollection0.remove((java.lang.Object) strComparableCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray16), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray16), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "[]" + "'", str20, "[]");
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray21), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray21), "[]");
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        // The following exception was thrown during execution in test generation
        try {
            int int35 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean34 = strComparableCollection18.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection33 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean34 = strComparableCollection33.isEmpty();
        boolean boolean36 = strComparableCollection33.equals((java.lang.Object) 1.0d);
        boolean boolean38 = strComparableCollection33.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection39 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean40 = strComparableCollection39.isEmpty();
        java.lang.Object[] objArray41 = strComparableCollection39.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator42 = strComparableCollection39.spliterator();
        boolean boolean43 = strComparableCollection33.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection39);
        int int44 = strComparableCollection33.size();
        java.lang.String str45 = strComparableCollection33.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean46 = strComparableCollection18.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray41), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray41), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "[]" + "'", str45, "[]");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.util.AbstractList[] abstractListArray5 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray6 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray5;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray7 = strComparableCollection0.toArray(strComparableListArray6);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream8 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str10 = strComparableCollection9.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(abstractListArray5);
        org.junit.Assert.assertNotNull(strComparableListArray6);
        org.junit.Assert.assertNotNull(strComparableListArray7);
        org.junit.Assert.assertNotNull(strComparableStream8);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "[]" + "'", str10, "[]");
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        // The following exception was thrown during execution in test generation
        try {
            int int13 = strComparableCollection6.add((java.lang.Comparable<java.lang.String>) "[]", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        boolean boolean13 = strComparableCollection8.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection14 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean15 = strComparableCollection14.isEmpty();
        java.lang.Object[] objArray16 = strComparableCollection14.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator17 = strComparableCollection14.spliterator();
        boolean boolean18 = strComparableCollection8.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection14);
        boolean boolean19 = strComparableCollection2.equals((java.lang.Object) boolean18);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean20 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray16), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray16), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection0.entrySet();
        int int14 = strComparableCollection0.size();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet15 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Object> objCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Object>();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = strComparableCollection0.remove((java.lang.Object) objCollection16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strComparableEntrySet15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray24 = strComparableCollection17.toArray((java.lang.Comparable<java.lang.String>[]) strArray23);
        java.lang.CharSequence[] charSequenceArray25 = strComparableCollection8.toArray((java.lang.CharSequence[]) strArray23);
        boolean boolean26 = strComparableCollection0.equals((java.lang.Object) strComparableCollection8);
        java.lang.Object[] objArray27 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean29 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(charSequenceArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray27), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray27), "[]");
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str6 = strComparableCollection5.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean8 = strComparableCollection7.isEmpty();
        boolean boolean10 = strComparableCollection7.equals((java.lang.Object) 1.0d);
        boolean boolean12 = strComparableCollection7.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        boolean boolean16 = strComparableCollection13.equals((java.lang.Object) 1.0d);
        int int17 = strComparableCollection13.size();
        java.lang.String str18 = strComparableCollection13.toString();
        java.util.Collection[] collectionArray20 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray20;
        strComparableCollectionArray21[0] = strComparableCollection7;
        strComparableCollectionArray21[1] = strComparableCollection13;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray26 = strComparableCollection5.toArray(strComparableCollectionArray21);
        java.util.Collection[] collectionArray28 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray28;
        java.util.Collection[][] collectionArray31 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray32 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray31;
        strComparableCollectionArray32[0] = collectionArray28;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray35 = strComparableCollection5.toArray(strComparableCollectionArray32);
        java.lang.Object[][] objArray36 = strComparableCollection0.toArray((java.lang.Object[][]) strComparableCollectionArray32);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean38 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "[]" + "'", str18, "[]");
        org.junit.Assert.assertNotNull(collectionArray20);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(strComparableCollectionArray26);
        org.junit.Assert.assertNotNull(collectionArray28);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(collectionArray31);
        org.junit.Assert.assertNotNull(strComparableCollectionArray32);
        org.junit.Assert.assertNotNull(strComparableCollectionArray35);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.CharSequence[]> charSequenceArrayCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.CharSequence[]>();
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int9 = strComparableCollection0.getCount((java.lang.Object) 0L);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet10 = strComparableCollection0.uniqueSet();
        java.lang.Class<?> wildcardClass11 = strComparableSet10.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(strComparableSet10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet5 = strComparableCollection0.entrySet();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(strComparableEntrySet5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        boolean boolean16 = strComparableCollection13.equals((java.lang.Object) 1.0d);
        boolean boolean18 = strComparableCollection13.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        boolean boolean22 = strComparableCollection19.equals((java.lang.Object) 1.0d);
        boolean boolean24 = strComparableCollection19.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection25 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean26 = strComparableCollection25.isEmpty();
        java.lang.Object[] objArray27 = strComparableCollection25.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator28 = strComparableCollection25.spliterator();
        boolean boolean29 = strComparableCollection19.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection25);
        boolean boolean30 = strComparableCollection13.equals((java.lang.Object) boolean29);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection31 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean32 = strComparableCollection31.isEmpty();
        boolean boolean34 = strComparableCollection31.equals((java.lang.Object) 1.0d);
        boolean boolean36 = strComparableCollection31.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection37 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean38 = strComparableCollection37.isEmpty();
        java.lang.Object[] objArray39 = strComparableCollection37.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator40 = strComparableCollection37.spliterator();
        boolean boolean41 = strComparableCollection31.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection37);
        int int42 = strComparableCollection31.size();
        java.lang.String str43 = strComparableCollection31.toString();
        boolean boolean44 = strComparableCollection13.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection31);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor45 = strComparableCollection13.iterator();
        java.lang.Class<?> wildcardClass46 = strComparableItor45.getClass();
        boolean boolean47 = strComparableCollection3.contains((java.lang.Object) strComparableItor45);
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray27), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray27), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray39), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray39), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "[]" + "'", str43, "[]");
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(strComparableItor45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        int int16 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet7 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet11 = strComparableCollection8.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableSet11);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableEntrySet7);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSet11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        boolean boolean15 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableSet8.parallelStream();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableSet8);
        org.junit.Assert.assertNotNull(strComparableStream9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        int int14 = strComparableCollection10.size();
        java.lang.String str15 = strComparableCollection10.toString();
        int int17 = strComparableCollection10.getCount((java.lang.Object) 0.0f);
        int int18 = strComparableCollection10.size();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean19 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "[]" + "'", str15, "[]");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        int int33 = strComparableCollection8.size();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet34 = strComparableCollection8.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(strComparableEntrySet34);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        int int4 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection14 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean15 = strComparableCollection14.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        boolean boolean33 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        br.com.unicamp.mo409.UnmodifiableMultiSet<org.apache.commons.collections4.Unmodifiable> unmodifiableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<org.apache.commons.collections4.Unmodifiable>();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        java.lang.String str4 = strComparableCollection0.toString();
        java.lang.String str5 = strComparableCollection0.toString();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        boolean boolean6 = strComparableCollection3.equals((java.lang.Object) 1.0d);
        int int7 = strComparableCollection3.size();
        java.lang.String str8 = strComparableCollection3.toString();
        int int10 = strComparableCollection3.getCount((java.lang.Object) 0.0f);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean11 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        boolean boolean22 = strComparableCollection19.equals((java.lang.Object) 1.0d);
        int int23 = strComparableCollection19.size();
        java.lang.String str24 = strComparableCollection19.toString();
        int int26 = strComparableCollection19.getCount((java.lang.Object) 0.0f);
        java.lang.String str27 = strComparableCollection19.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream28 = strComparableCollection19.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean29 = strComparableCollection0.remove((java.lang.Object) strComparableStream28);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "[]" + "'", str27, "[]");
        org.junit.Assert.assertNotNull(strComparableStream28);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection0.stream();
        java.lang.String str16 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        boolean boolean20 = strComparableCollection17.equals((java.lang.Object) 1.0d);
        int int21 = strComparableCollection17.size();
        java.lang.Class<?> wildcardClass22 = strComparableCollection17.getClass();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean23 = strComparableCollection0.remove((java.lang.Object) strComparableCollection17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableStream15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        int int20 = strComparableCollection9.size();
        int int21 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection23 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str24 = strComparableCollection23.toString();
        java.lang.Object[] objArray25 = strComparableCollection23.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet26 = strComparableCollection23.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean27 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableSet26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray25), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray25), "[]");
        org.junit.Assert.assertNotNull(strComparableSet26);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator4 = strComparableCollection0.spliterator();
        boolean boolean5 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableSpliterator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor32 = strComparableCollection0.iterator();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor33 = strComparableCollection0.iterator();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor34 = strComparableCollection0.iterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableItor32);
        org.junit.Assert.assertNotNull(strComparableItor33);
        org.junit.Assert.assertNotNull(strComparableItor34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet33 = strComparableCollection18.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection34 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean35 = strComparableCollection34.isEmpty();
        boolean boolean37 = strComparableCollection34.contains((java.lang.Object) 1);
        boolean boolean39 = strComparableCollection34.contains((java.lang.Object) "[]");
        java.lang.String str40 = strComparableCollection34.toString();
        int int41 = strComparableCollection34.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str43 = strComparableCollection42.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection44 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean45 = strComparableCollection44.isEmpty();
        boolean boolean47 = strComparableCollection44.equals((java.lang.Object) 1.0d);
        boolean boolean49 = strComparableCollection44.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection50 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean51 = strComparableCollection50.isEmpty();
        boolean boolean53 = strComparableCollection50.equals((java.lang.Object) 1.0d);
        int int54 = strComparableCollection50.size();
        java.lang.String str55 = strComparableCollection50.toString();
        java.util.Collection[] collectionArray57 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray58 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray57;
        strComparableCollectionArray58[0] = strComparableCollection44;
        strComparableCollectionArray58[1] = strComparableCollection50;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray63 = strComparableCollection42.toArray(strComparableCollectionArray58);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator64 = strComparableCollection42.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream65 = strComparableCollection42.stream();
        int int66 = strComparableCollection34.getCount((java.lang.Object) strComparableCollection42);
        java.lang.Object[] objArray67 = strComparableCollection34.toArray();
        int int68 = strComparableCollection34.size();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean69 = strComparableCollection18.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableEntrySet33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "[]" + "'", str40, "[]");
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "[]" + "'", str43, "[]");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "[]" + "'", str55, "[]");
        org.junit.Assert.assertNotNull(collectionArray57);
        org.junit.Assert.assertNotNull(strComparableCollectionArray58);
        org.junit.Assert.assertNotNull(strComparableCollectionArray63);
        org.junit.Assert.assertNotNull(strComparableSpliterator64);
        org.junit.Assert.assertNotNull(strComparableStream65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray67), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray67), "[]");
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream8 = strComparableCollection0.parallelStream();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertNotNull(strComparableStream8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        java.lang.Class<?> wildcardClass4 = strComparableCollection0.getClass();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean5 = strComparableCollection0.equals((java.lang.Object) (byte) 0);
        java.lang.Class<?> wildcardClass6 = strComparableCollection0.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.util.AbstractList[] abstractListArray5 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray6 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray5;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray7 = strComparableCollection0.toArray(strComparableListArray6);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream8 = strComparableCollection0.stream();
        int int9 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(abstractListArray5);
        org.junit.Assert.assertNotNull(strComparableListArray6);
        org.junit.Assert.assertNotNull(strComparableListArray7);
        org.junit.Assert.assertNotNull(strComparableStream8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass9 = strComparableListCollection8.getClass();
        java.lang.reflect.Type[] typeArray10 = new java.lang.reflect.Type[] { wildcardClass9 };
        java.lang.reflect.Type[] typeArray11 = strComparableCollection0.toArray(typeArray10);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet12 = strComparableCollection0.entrySet();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(typeArray10);
        org.junit.Assert.assertNotNull(typeArray11);
        org.junit.Assert.assertNotNull(strComparableEntrySet12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet33 = strComparableCollection18.entrySet();
        int int34 = strComparableCollection18.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableEntrySet33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        java.lang.CharSequence[][] charSequenceArray32 = new java.lang.CharSequence[][] {};
        java.lang.CharSequence[][] charSequenceArray33 = strComparableCollection4.toArray(charSequenceArray32);
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection4.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection0.parallelStream();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection0.iterator();
        java.lang.Class<?> wildcardClass17 = strComparableItor16.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableStream15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet4 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream5 = strComparableSet4.parallelStream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strComparableSet4);
        org.junit.Assert.assertNotNull(strComparableStream5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int9 = strComparableCollection0.getCount((java.lang.Object) 0L);
        java.lang.String str10 = strComparableCollection0.toString();
        // The following exception was thrown during execution in test generation
        try {
            int int13 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "[]", (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "[]" + "'", str10, "[]");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        java.lang.Object[] objArray30 = strComparableCollection1.toArray();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray30), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray30), "[]");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Collection[] collectionArray7 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray8 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray7;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = strComparableCollection3.toArray(strComparableCollectionArray8);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator10 = strComparableCollection3.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection11 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean12 = strComparableCollection11.isEmpty();
        java.lang.Object[] objArray13 = strComparableCollection11.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator14 = strComparableCollection11.spliterator();
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray18 = strComparableCollection11.toArray((java.lang.Comparable<java.lang.String>[]) strArray17);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor19 = strComparableCollection11.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection20 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean21 = strComparableCollection20.isEmpty();
        java.lang.Object[] objArray22 = strComparableCollection20.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator23 = strComparableCollection20.spliterator();
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray27 = strComparableCollection20.toArray((java.lang.Comparable<java.lang.String>[]) strArray26);
        java.lang.CharSequence[] charSequenceArray28 = strComparableCollection11.toArray((java.lang.CharSequence[]) strArray26);
        boolean boolean29 = strComparableCollection3.equals((java.lang.Object) strComparableCollection11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean30 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(collectionArray7);
        org.junit.Assert.assertNotNull(strComparableCollectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableSpliterator10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strComparableArray18);
        org.junit.Assert.assertNotNull(strComparableItor19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray22), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray22), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator23);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strComparableArray27);
        org.junit.Assert.assertNotNull(charSequenceArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet4 = strComparableCollection0.uniqueSet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str6 = strComparableCollection5.toString();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.lang.Class<?> wildcardClass8 = objArray7.getClass();
        boolean boolean9 = strComparableCollection0.contains((java.lang.Object) wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strComparableSet4);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection5.spliterator();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray12 = strComparableCollection5.toArray((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection5.iterator();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableItor13);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection0.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strComparableItor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        java.lang.CharSequence[][] charSequenceArray32 = new java.lang.CharSequence[][] {};
        java.lang.CharSequence[][] charSequenceArray33 = strComparableCollection4.toArray(charSequenceArray32);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator34 = strComparableCollection4.spliterator();
        java.lang.Class<?> wildcardClass35 = strComparableCollection4.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
        org.junit.Assert.assertNotNull(strComparableSpliterator34);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        boolean boolean11 = strComparableCollection6.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream12 = strComparableCollection6.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(strComparableStream12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.lang.Object[] objArray4 = strComparableCollection0.toArray();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray4), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray4), "[]");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.lang.Object[] objArray6 = strComparableCollection3.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str8 = strComparableCollection7.toString();
        java.lang.Object[] objArray9 = strComparableCollection7.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray17 = strComparableCollection10.toArray((java.lang.Comparable<java.lang.String>[]) strArray16);
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList21 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean23 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean24 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream25 = strComparableList21.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableList21.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection27 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str28 = strComparableCollection27.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection29 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean30 = strComparableCollection29.isEmpty();
        boolean boolean32 = strComparableCollection29.equals((java.lang.Object) 1.0d);
        boolean boolean34 = strComparableCollection29.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        boolean boolean38 = strComparableCollection35.equals((java.lang.Object) 1.0d);
        int int39 = strComparableCollection35.size();
        java.lang.String str40 = strComparableCollection35.toString();
        java.util.Collection[] collectionArray42 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray43 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray42;
        strComparableCollectionArray43[0] = strComparableCollection29;
        strComparableCollectionArray43[1] = strComparableCollection35;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray48 = strComparableCollection27.toArray(strComparableCollectionArray43);
        java.lang.Cloneable[] cloneableArray49 = new java.lang.Cloneable[] { objArray6, objArray9, strComparableArray17, strComparableList21, strComparableCollectionArray43 };
        java.lang.Cloneable[] cloneableArray50 = strComparableCollection0.toArray(cloneableArray49);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean52 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strComparableArray17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strComparableStream25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "[]" + "'", str28, "[]");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "[]" + "'", str40, "[]");
        org.junit.Assert.assertNotNull(collectionArray42);
        org.junit.Assert.assertNotNull(strComparableCollectionArray43);
        org.junit.Assert.assertNotNull(strComparableCollectionArray48);
        org.junit.Assert.assertNotNull(cloneableArray49);
        org.junit.Assert.assertNotNull(cloneableArray50);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.util.AbstractList[] abstractListArray5 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray6 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray5;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray7 = strComparableCollection0.toArray(strComparableListArray6);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean10 = strComparableCollection8.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection8.stream();
        int int12 = strComparableCollection8.size();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(abstractListArray5);
        org.junit.Assert.assertNotNull(strComparableListArray6);
        org.junit.Assert.assertNotNull(strComparableListArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        int int6 = strComparableCollection2.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str8 = strComparableCollection7.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        boolean boolean18 = strComparableCollection15.equals((java.lang.Object) 1.0d);
        int int19 = strComparableCollection15.size();
        java.lang.String str20 = strComparableCollection15.toString();
        java.util.Collection[] collectionArray22 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray23 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray22;
        strComparableCollectionArray23[0] = strComparableCollection9;
        strComparableCollectionArray23[1] = strComparableCollection15;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray28 = strComparableCollection7.toArray(strComparableCollectionArray23);
        java.util.Collection[] collectionArray30 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray31 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray30;
        java.util.Collection[][] collectionArray33 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray34 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray33;
        strComparableCollectionArray34[0] = collectionArray30;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray37 = strComparableCollection7.toArray(strComparableCollectionArray34);
        java.lang.Object[][] objArray38 = strComparableCollection2.toArray((java.lang.Object[][]) strComparableCollectionArray34);
        java.lang.Object[][] objArray39 = strComparableCollection0.toArray(objArray38);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "[]" + "'", str20, "[]");
        org.junit.Assert.assertNotNull(collectionArray22);
        org.junit.Assert.assertNotNull(strComparableCollectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray28);
        org.junit.Assert.assertNotNull(collectionArray30);
        org.junit.Assert.assertNotNull(strComparableCollectionArray31);
        org.junit.Assert.assertNotNull(collectionArray33);
        org.junit.Assert.assertNotNull(strComparableCollectionArray34);
        org.junit.Assert.assertNotNull(strComparableCollectionArray37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str6 = strComparableCollection5.toString();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Collection[] collectionArray9 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray9;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray11 = strComparableCollection5.toArray(strComparableCollectionArray10);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection5.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        java.lang.Object[] objArray15 = strComparableCollection13.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator16 = strComparableCollection13.spliterator();
        java.lang.String[] strArray19 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray20 = strComparableCollection13.toArray((java.lang.Comparable<java.lang.String>[]) strArray19);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor21 = strComparableCollection13.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        java.lang.Object[] objArray24 = strComparableCollection22.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator25 = strComparableCollection22.spliterator();
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray29 = strComparableCollection22.toArray((java.lang.Comparable<java.lang.String>[]) strArray28);
        java.lang.CharSequence[] charSequenceArray30 = strComparableCollection13.toArray((java.lang.CharSequence[]) strArray28);
        boolean boolean31 = strComparableCollection5.equals((java.lang.Object) strComparableCollection13);
        java.lang.Object[] objArray32 = strComparableCollection5.toArray();
        boolean boolean33 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection5);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean34 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(collectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableCollectionArray11);
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray15), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray15), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator16);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strComparableArray20);
        org.junit.Assert.assertNotNull(strComparableItor21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray24), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray24), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator25);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(strComparableArray29);
        org.junit.Assert.assertNotNull(charSequenceArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray32), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray32), "[]");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str10 = strComparableCollection9.toString();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Collection[] collectionArray13 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray14 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray13;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray15 = strComparableCollection9.toArray(strComparableCollectionArray14);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator16 = strComparableCollection9.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet17 = strComparableCollection9.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            int int19 = strComparableCollection0.remove((java.lang.Object) strComparableCollection9, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "[]" + "'", str10, "[]");
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(collectionArray13);
        org.junit.Assert.assertNotNull(strComparableCollectionArray14);
        org.junit.Assert.assertNotNull(strComparableCollectionArray15);
        org.junit.Assert.assertNotNull(strComparableSpliterator16);
        org.junit.Assert.assertNotNull(strComparableSet17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.lang.Object[] objArray22 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor23 = strComparableCollection0.iterator();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray22), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray22), "[]");
        org.junit.Assert.assertNotNull(strComparableItor23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        boolean boolean16 = strComparableCollection0.equals((java.lang.Object) "");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream17 = strComparableCollection0.parallelStream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strComparableStream17);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String str4 = strComparableCollection0.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection0.entrySet();
        int int14 = strComparableCollection0.size();
        boolean boolean15 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean20 = strComparableCollection0.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet11 = strComparableCollection0.entrySet();
        java.lang.String str12 = strComparableCollection0.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet11);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream8 = strComparableCollection0.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableStream8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor8 = strComparableCollection0.iterator();
        int int9 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strComparableItor8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean4 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str6 = strComparableCollection5.toString();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Collection[] collectionArray9 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray9;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray11 = strComparableCollection5.toArray(strComparableCollectionArray10);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection5.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass14 = strComparableListCollection13.getClass();
        java.lang.reflect.Type[] typeArray15 = new java.lang.reflect.Type[] { wildcardClass14 };
        java.lang.reflect.Type[] typeArray16 = strComparableCollection5.toArray(typeArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection5.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean18 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(collectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableCollectionArray11);
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(typeArray15);
        org.junit.Assert.assertNotNull(typeArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        int int33 = strComparableCollection8.size();
        java.lang.Object[] objArray34 = strComparableCollection8.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str36 = strComparableCollection35.toString();
        java.lang.Object[] objArray37 = strComparableCollection35.toArray();
        java.util.Collection[] collectionArray39 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray40 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray39;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray41 = strComparableCollection35.toArray(strComparableCollectionArray40);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator42 = strComparableCollection35.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection43 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean44 = strComparableCollection43.isEmpty();
        java.lang.Object[] objArray45 = strComparableCollection43.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator46 = strComparableCollection43.spliterator();
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray50 = strComparableCollection43.toArray((java.lang.Comparable<java.lang.String>[]) strArray49);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor51 = strComparableCollection43.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection52 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean53 = strComparableCollection52.isEmpty();
        java.lang.Object[] objArray54 = strComparableCollection52.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator55 = strComparableCollection52.spliterator();
        java.lang.String[] strArray58 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray59 = strComparableCollection52.toArray((java.lang.Comparable<java.lang.String>[]) strArray58);
        java.lang.CharSequence[] charSequenceArray60 = strComparableCollection43.toArray((java.lang.CharSequence[]) strArray58);
        boolean boolean61 = strComparableCollection35.equals((java.lang.Object) strComparableCollection43);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor62 = strComparableCollection43.iterator();
        boolean boolean63 = strComparableCollection43.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream64 = strComparableCollection43.stream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean65 = strComparableCollection8.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray34), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray34), "[]");
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "[]" + "'", str36, "[]");
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray37), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray37), "[]");
        org.junit.Assert.assertNotNull(collectionArray39);
        org.junit.Assert.assertNotNull(strComparableCollectionArray40);
        org.junit.Assert.assertNotNull(strComparableCollectionArray41);
        org.junit.Assert.assertNotNull(strComparableSpliterator42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray45), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray45), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator46);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(strComparableArray50);
        org.junit.Assert.assertNotNull(strComparableItor51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray54), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray54), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator55);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(strComparableArray59);
        org.junit.Assert.assertNotNull(charSequenceArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strComparableItor62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(strComparableStream64);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int8 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator10 = strComparableCollection9.spliterator();
        java.lang.String str11 = strComparableCollection9.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.util.AbstractList[] abstractListArray17 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray18 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray17;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray19 = strComparableCollection12.toArray(strComparableListArray18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream20 = strComparableCollection12.stream();
        boolean boolean21 = strComparableCollection9.equals((java.lang.Object) strComparableCollection12);
        int int22 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator10);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(abstractListArray17);
        org.junit.Assert.assertNotNull(strComparableListArray18);
        org.junit.Assert.assertNotNull(strComparableListArray19);
        org.junit.Assert.assertNotNull(strComparableStream20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean4 = strComparableCollection0.isEmpty();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator5 = strComparableCollection0.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            int int8 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "", (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(strComparableSpliterator5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str14 = strComparableCollection13.toString();
        java.lang.Object[] objArray15 = strComparableCollection13.toArray();
        java.lang.Object[] objArray16 = strComparableCollection13.toArray();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = strComparableCollection0.remove((java.lang.Object) objArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "[]" + "'", str14, "[]");
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray15), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray15), "[]");
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray16), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray16), "[]");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection11 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str12 = strComparableCollection11.toString();
        java.lang.Object[] objArray13 = strComparableCollection11.toArray();
        java.util.Collection[] collectionArray15 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray17 = strComparableCollection11.toArray(strComparableCollectionArray16);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection11.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass20 = strComparableListCollection19.getClass();
        java.lang.reflect.Type[] typeArray21 = new java.lang.reflect.Type[] { wildcardClass20 };
        java.lang.reflect.Type[] typeArray22 = strComparableCollection11.toArray(typeArray21);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor23 = strComparableCollection11.iterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet24 = strComparableCollection11.uniqueSet();
        int int25 = strComparableCollection6.getCount((java.lang.Object) strComparableSet24);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection26 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean27 = strComparableCollection26.isEmpty();
        boolean boolean29 = strComparableCollection26.contains((java.lang.Object) 1);
        boolean boolean31 = strComparableCollection26.contains((java.lang.Object) "[]");
        java.lang.String str32 = strComparableCollection26.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor33 = strComparableCollection26.iterator();
        boolean boolean34 = strComparableCollection6.equals((java.lang.Object) strComparableItor33);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray17);
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(typeArray21);
        org.junit.Assert.assertNotNull(typeArray22);
        org.junit.Assert.assertNotNull(strComparableItor23);
        org.junit.Assert.assertNotNull(strComparableSet24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "[]" + "'", str32, "[]");
        org.junit.Assert.assertNotNull(strComparableItor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        int int10 = strComparableCollection6.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection11 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str12 = strComparableCollection11.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        boolean boolean16 = strComparableCollection13.equals((java.lang.Object) 1.0d);
        boolean boolean18 = strComparableCollection13.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        boolean boolean22 = strComparableCollection19.equals((java.lang.Object) 1.0d);
        int int23 = strComparableCollection19.size();
        java.lang.String str24 = strComparableCollection19.toString();
        java.util.Collection[] collectionArray26 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray27 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray26;
        strComparableCollectionArray27[0] = strComparableCollection13;
        strComparableCollectionArray27[1] = strComparableCollection19;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray32 = strComparableCollection11.toArray(strComparableCollectionArray27);
        java.util.Collection[] collectionArray34 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray35 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray34;
        java.util.Collection[][] collectionArray37 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray38 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray37;
        strComparableCollectionArray38[0] = collectionArray34;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray41 = strComparableCollection11.toArray(strComparableCollectionArray38);
        java.lang.Object[][] objArray42 = strComparableCollection6.toArray((java.lang.Object[][]) strComparableCollectionArray38);
        boolean boolean43 = strComparableCollection0.contains((java.lang.Object) strComparableCollection6);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection44 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str45 = strComparableCollection44.toString();
        java.lang.Object[] objArray46 = strComparableCollection44.toArray();
        java.util.Collection[] collectionArray48 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray49 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray48;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray50 = strComparableCollection44.toArray(strComparableCollectionArray49);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet51 = strComparableCollection44.entrySet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet52 = strComparableCollection44.uniqueSet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet53 = strComparableCollection44.uniqueSet();
        int int54 = strComparableCollection6.getCount((java.lang.Object) strComparableCollection44);
        int int55 = strComparableCollection6.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertNotNull(collectionArray26);
        org.junit.Assert.assertNotNull(strComparableCollectionArray27);
        org.junit.Assert.assertNotNull(strComparableCollectionArray32);
        org.junit.Assert.assertNotNull(collectionArray34);
        org.junit.Assert.assertNotNull(strComparableCollectionArray35);
        org.junit.Assert.assertNotNull(collectionArray37);
        org.junit.Assert.assertNotNull(strComparableCollectionArray38);
        org.junit.Assert.assertNotNull(strComparableCollectionArray41);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "[]" + "'", str45, "[]");
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray46), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray46), "[]");
        org.junit.Assert.assertNotNull(collectionArray48);
        org.junit.Assert.assertNotNull(strComparableCollectionArray49);
        org.junit.Assert.assertNotNull(strComparableCollectionArray50);
        org.junit.Assert.assertNotNull(strComparableEntrySet51);
        org.junit.Assert.assertNotNull(strComparableSet52);
        org.junit.Assert.assertNotNull(strComparableSet53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            int int11 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "[]", (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection10.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(strComparableStream15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int8 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str10 = strComparableCollection9.toString();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet12 = strComparableCollection9.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection9.parallelStream();
        java.lang.Object[] objArray14 = strComparableCollection9.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection9.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.remove((java.lang.Object) strComparableCollection9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "[]" + "'", str10, "[]");
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSet12);
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableStream15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        java.lang.String str4 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream5 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection6.spliterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet8 = strComparableCollection6.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        int int13 = strComparableCollection9.size();
        java.lang.String str14 = strComparableCollection9.toString();
        int int16 = strComparableCollection9.getCount((java.lang.Object) 0.0f);
        java.lang.String str17 = strComparableCollection9.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream18 = strComparableCollection9.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        java.lang.Object[] objArray21 = strComparableCollection19.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream22 = strComparableCollection19.stream();
        boolean boolean23 = strComparableCollection9.equals((java.lang.Object) strComparableCollection19);
        int int24 = strComparableCollection6.getCount((java.lang.Object) strComparableCollection9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean25 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(strComparableStream5);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableEntrySet8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "[]" + "'", str14, "[]");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
        org.junit.Assert.assertNotNull(strComparableStream18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray21), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray21), "[]");
        org.junit.Assert.assertNotNull(strComparableStream22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet2 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        boolean boolean6 = strComparableCollection3.equals((java.lang.Object) 1.0d);
        int int7 = strComparableCollection3.size();
        java.lang.String str8 = strComparableCollection3.toString();
        int int10 = strComparableCollection3.getCount((java.lang.Object) 0.0f);
        java.lang.String str11 = strComparableCollection3.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream12 = strComparableCollection3.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        java.lang.Object[] objArray15 = strComparableCollection13.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream16 = strComparableCollection13.stream();
        boolean boolean17 = strComparableCollection3.equals((java.lang.Object) strComparableCollection13);
        int int18 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection3);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet19 = strComparableCollection3.uniqueSet();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertNotNull(strComparableEntrySet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertNotNull(strComparableStream12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray15), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray15), "[]");
        org.junit.Assert.assertNotNull(strComparableStream16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(strComparableSet19);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        // The following exception was thrown during execution in test generation
        try {
            int int20 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean4 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        // The following exception was thrown during execution in test generation
        try {
            int int32 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.parallelStream();
        java.lang.Object[] objArray5 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection0.spliterator();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.util.Collection[] collectionArray23 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        java.util.Collection[][] collectionArray26 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray27 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray26;
        strComparableCollectionArray27[0] = collectionArray23;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray30 = strComparableCollection0.toArray(strComparableCollectionArray27);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection31 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean32 = strComparableCollection31.isEmpty();
        java.lang.Object[] objArray33 = strComparableCollection31.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream34 = strComparableCollection31.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream35 = strComparableCollection31.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet36 = strComparableCollection31.entrySet();
        boolean boolean37 = strComparableCollection0.contains((java.lang.Object) strComparableCollection31);
        int int38 = strComparableCollection31.size();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet39 = strComparableCollection31.uniqueSet();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(collectionArray26);
        org.junit.Assert.assertNotNull(strComparableCollectionArray27);
        org.junit.Assert.assertNotNull(strComparableCollectionArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray33), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray33), "[]");
        org.junit.Assert.assertNotNull(strComparableStream34);
        org.junit.Assert.assertNotNull(strComparableStream35);
        org.junit.Assert.assertNotNull(strComparableEntrySet36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(strComparableSet39);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.GenericDeclaration> genericDeclarationCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.GenericDeclaration>();
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        java.lang.String str30 = strComparableCollection1.toString();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet31 = strComparableCollection1.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableSet31.stream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator33 = strComparableSet31.spliterator();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertNotNull(strComparableSet31);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableSpliterator33);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator4 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        boolean boolean8 = strComparableCollection5.contains((java.lang.Object) 1);
        boolean boolean10 = strComparableCollection5.contains((java.lang.Object) "[]");
        java.lang.String str11 = strComparableCollection5.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor12 = strComparableCollection5.iterator();
        int int13 = strComparableCollection5.size();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean14 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableSpliterator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertNotNull(strComparableItor12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator14 = strComparableCollection13.spliterator();
        java.lang.String str15 = strComparableCollection13.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection13.iterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = strComparableCollection3.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strComparableSpliterator14);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "[]" + "'", str15, "[]");
        org.junit.Assert.assertNotNull(strComparableItor16);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection0.entrySet();
        int int14 = strComparableCollection0.size();
        boolean boolean15 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        boolean boolean21 = strComparableCollection16.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        java.lang.Object[] objArray24 = strComparableCollection22.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator25 = strComparableCollection22.spliterator();
        boolean boolean26 = strComparableCollection16.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection22);
        int int27 = strComparableCollection16.size();
        java.lang.String str28 = strComparableCollection16.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream29 = strComparableCollection16.parallelStream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet30 = strComparableCollection16.uniqueSet();
        int int31 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection16);
        // The following exception was thrown during execution in test generation
        try {
            int int34 = strComparableCollection16.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray24), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray24), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "[]" + "'", str28, "[]");
        org.junit.Assert.assertNotNull(strComparableStream29);
        org.junit.Assert.assertNotNull(strComparableSet30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean4 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection0.toArray();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor23 = strComparableCollection0.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str25 = strComparableCollection24.toString();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Collection[] collectionArray28 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray28;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray30 = strComparableCollection24.toArray(strComparableCollectionArray29);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator31 = strComparableCollection24.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection32 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass33 = strComparableListCollection32.getClass();
        java.lang.reflect.Type[] typeArray34 = new java.lang.reflect.Type[] { wildcardClass33 };
        java.lang.reflect.Type[] typeArray35 = strComparableCollection24.toArray(typeArray34);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor36 = strComparableCollection24.iterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet37 = strComparableCollection24.uniqueSet();
        java.lang.Object[] objArray38 = strComparableCollection24.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream39 = strComparableCollection24.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int41 = strComparableCollection0.remove((java.lang.Object) strComparableStream39, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
        org.junit.Assert.assertNotNull(strComparableItor23);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "[]" + "'", str25, "[]");
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(collectionArray28);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableCollectionArray30);
        org.junit.Assert.assertNotNull(strComparableSpliterator31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(typeArray34);
        org.junit.Assert.assertNotNull(typeArray35);
        org.junit.Assert.assertNotNull(strComparableItor36);
        org.junit.Assert.assertNotNull(strComparableSet37);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray38), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray38), "[]");
        org.junit.Assert.assertNotNull(strComparableStream39);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        int int33 = strComparableCollection8.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection34 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str35 = strComparableCollection34.toString();
        java.lang.Object[] objArray36 = strComparableCollection34.toArray();
        java.util.Collection[] collectionArray38 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray39 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray38;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray40 = strComparableCollection34.toArray(strComparableCollectionArray39);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator41 = strComparableCollection34.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass43 = strComparableListCollection42.getClass();
        java.lang.reflect.Type[] typeArray44 = new java.lang.reflect.Type[] { wildcardClass43 };
        java.lang.reflect.Type[] typeArray45 = strComparableCollection34.toArray(typeArray44);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream46 = strComparableCollection34.parallelStream();
        java.lang.Object[] objArray47 = strComparableCollection34.toArray();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean48 = strComparableCollection8.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "[]" + "'", str35, "[]");
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray36), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray36), "[]");
        org.junit.Assert.assertNotNull(collectionArray38);
        org.junit.Assert.assertNotNull(strComparableCollectionArray39);
        org.junit.Assert.assertNotNull(strComparableCollectionArray40);
        org.junit.Assert.assertNotNull(strComparableSpliterator41);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(typeArray44);
        org.junit.Assert.assertNotNull(typeArray45);
        org.junit.Assert.assertNotNull(strComparableStream46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray47), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray47), "[]");
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        boolean boolean11 = strComparableCollection6.isEmpty();
        int int12 = strComparableCollection6.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection30 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean31 = strComparableCollection30.isEmpty();
        boolean boolean33 = strComparableCollection30.equals((java.lang.Object) 1.0d);
        boolean boolean35 = strComparableCollection30.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection36 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean37 = strComparableCollection36.isEmpty();
        boolean boolean39 = strComparableCollection36.equals((java.lang.Object) 1.0d);
        boolean boolean41 = strComparableCollection36.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean43 = strComparableCollection42.isEmpty();
        java.lang.Object[] objArray44 = strComparableCollection42.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator45 = strComparableCollection42.spliterator();
        boolean boolean46 = strComparableCollection36.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection42);
        boolean boolean47 = strComparableCollection30.equals((java.lang.Object) boolean46);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection48 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean49 = strComparableCollection48.isEmpty();
        boolean boolean51 = strComparableCollection48.equals((java.lang.Object) 1.0d);
        boolean boolean53 = strComparableCollection48.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection54 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean55 = strComparableCollection54.isEmpty();
        java.lang.Object[] objArray56 = strComparableCollection54.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator57 = strComparableCollection54.spliterator();
        boolean boolean58 = strComparableCollection48.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection54);
        int int59 = strComparableCollection48.size();
        java.lang.String str60 = strComparableCollection48.toString();
        boolean boolean61 = strComparableCollection30.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection48);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor62 = strComparableCollection30.iterator();
        boolean boolean63 = strComparableCollection0.equals((java.lang.Object) strComparableCollection30);
        boolean boolean64 = strComparableCollection30.isEmpty();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray44), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray44), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray56), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray56), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "[]" + "'", str60, "[]");
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strComparableItor62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet2 = strComparableCollection0.entrySet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertNotNull(strComparableEntrySet2);
        org.junit.Assert.assertNotNull(strComparableStream3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet33 = strComparableCollection18.entrySet();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator34 = strComparableCollection18.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean36 = strComparableCollection18.add((java.lang.Comparable<java.lang.String>) "[]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableEntrySet33);
        org.junit.Assert.assertNotNull(strComparableSpliterator34);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator4 = strComparableCollection0.spliterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strComparableSpliterator4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection0.entrySet();
        int int14 = strComparableCollection0.size();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet15 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.contains((java.lang.Object) 1);
        boolean boolean21 = strComparableCollection16.contains((java.lang.Object) "[]");
        java.lang.String str22 = strComparableCollection16.toString();
        int int23 = strComparableCollection16.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str25 = strComparableCollection24.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection26 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean27 = strComparableCollection26.isEmpty();
        boolean boolean29 = strComparableCollection26.equals((java.lang.Object) 1.0d);
        boolean boolean31 = strComparableCollection26.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection32 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean33 = strComparableCollection32.isEmpty();
        boolean boolean35 = strComparableCollection32.equals((java.lang.Object) 1.0d);
        int int36 = strComparableCollection32.size();
        java.lang.String str37 = strComparableCollection32.toString();
        java.util.Collection[] collectionArray39 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray40 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray39;
        strComparableCollectionArray40[0] = strComparableCollection26;
        strComparableCollectionArray40[1] = strComparableCollection32;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray45 = strComparableCollection24.toArray(strComparableCollectionArray40);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator46 = strComparableCollection24.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream47 = strComparableCollection24.stream();
        int int48 = strComparableCollection16.getCount((java.lang.Object) strComparableCollection24);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean49 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strComparableEntrySet15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertEquals("'" + str22 + "' != '" + "[]" + "'", str22, "[]");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "[]" + "'", str25, "[]");
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "[]" + "'", str37, "[]");
        org.junit.Assert.assertNotNull(collectionArray39);
        org.junit.Assert.assertNotNull(strComparableCollectionArray40);
        org.junit.Assert.assertNotNull(strComparableCollectionArray45);
        org.junit.Assert.assertNotNull(strComparableSpliterator46);
        org.junit.Assert.assertNotNull(strComparableStream47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection32 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str33 = strComparableCollection32.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection34 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean35 = strComparableCollection34.isEmpty();
        boolean boolean37 = strComparableCollection34.equals((java.lang.Object) 1.0d);
        boolean boolean39 = strComparableCollection34.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection40 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean41 = strComparableCollection40.isEmpty();
        boolean boolean43 = strComparableCollection40.equals((java.lang.Object) 1.0d);
        int int44 = strComparableCollection40.size();
        java.lang.String str45 = strComparableCollection40.toString();
        java.util.Collection[] collectionArray47 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray48 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray47;
        strComparableCollectionArray48[0] = strComparableCollection34;
        strComparableCollectionArray48[1] = strComparableCollection40;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray53 = strComparableCollection32.toArray(strComparableCollectionArray48);
        java.util.Collection[] collectionArray55 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray56 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray55;
        java.util.Collection[][] collectionArray58 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray59 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray58;
        strComparableCollectionArray59[0] = collectionArray55;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray62 = strComparableCollection32.toArray(strComparableCollectionArray59);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection63 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean64 = strComparableCollection63.isEmpty();
        java.lang.Object[] objArray65 = strComparableCollection63.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream66 = strComparableCollection63.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream67 = strComparableCollection63.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet68 = strComparableCollection63.entrySet();
        boolean boolean69 = strComparableCollection32.contains((java.lang.Object) strComparableCollection63);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean70 = strComparableCollection0.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection63);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "[]" + "'", str33, "[]");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "[]" + "'", str45, "[]");
        org.junit.Assert.assertNotNull(collectionArray47);
        org.junit.Assert.assertNotNull(strComparableCollectionArray48);
        org.junit.Assert.assertNotNull(strComparableCollectionArray53);
        org.junit.Assert.assertNotNull(collectionArray55);
        org.junit.Assert.assertNotNull(strComparableCollectionArray56);
        org.junit.Assert.assertNotNull(collectionArray58);
        org.junit.Assert.assertNotNull(strComparableCollectionArray59);
        org.junit.Assert.assertNotNull(strComparableCollectionArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray65), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray65), "[]");
        org.junit.Assert.assertNotNull(strComparableStream66);
        org.junit.Assert.assertNotNull(strComparableStream67);
        org.junit.Assert.assertNotNull(strComparableEntrySet68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        int int9 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet13 = strComparableCollection0.entrySet();
        int int14 = strComparableCollection0.size();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet15 = strComparableCollection0.entrySet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream16 = strComparableCollection0.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strComparableEntrySet15);
        org.junit.Assert.assertNotNull(strComparableStream16);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection0.stream();
        java.lang.String str16 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet17 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableStream15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet17);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet10 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertNotNull(strComparableEntrySet10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        int int10 = strComparableCollection6.size();
        java.lang.String str11 = strComparableCollection6.toString();
        int int13 = strComparableCollection6.getCount((java.lang.Object) 0.0f);
        int int15 = strComparableCollection6.getCount((java.lang.Object) 0L);
        java.lang.String str16 = strComparableCollection6.toString();
        java.lang.String str17 = strComparableCollection6.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean18 = strComparableCollection0.retainAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        boolean boolean6 = strComparableCollection3.equals((java.lang.Object) 1.0d);
        boolean boolean8 = strComparableCollection3.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        boolean boolean20 = strComparableCollection3.equals((java.lang.Object) boolean19);
        java.lang.Class<?> wildcardClass21 = strComparableCollection3.getClass();
        boolean boolean22 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection23 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean24 = strComparableCollection23.isEmpty();
        java.lang.Object[] objArray25 = strComparableCollection23.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream26 = strComparableCollection23.stream();
        boolean boolean27 = strComparableCollection23.isEmpty();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean28 = strComparableCollection3.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray25), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray25), "[]");
        org.junit.Assert.assertNotNull(strComparableStream26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection5.spliterator();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray12 = strComparableCollection5.toArray((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection5.iterator();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableItor13);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection0.spliterator();
        java.lang.Object obj16 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = strComparableCollection0.remove(obj16);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strComparableItor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        boolean boolean16 = strComparableCollection0.equals((java.lang.Object) "");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean18 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection30 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean31 = strComparableCollection30.isEmpty();
        boolean boolean33 = strComparableCollection30.equals((java.lang.Object) 1.0d);
        boolean boolean35 = strComparableCollection30.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection36 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean37 = strComparableCollection36.isEmpty();
        boolean boolean39 = strComparableCollection36.equals((java.lang.Object) 1.0d);
        boolean boolean41 = strComparableCollection36.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean43 = strComparableCollection42.isEmpty();
        java.lang.Object[] objArray44 = strComparableCollection42.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator45 = strComparableCollection42.spliterator();
        boolean boolean46 = strComparableCollection36.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection42);
        boolean boolean47 = strComparableCollection30.equals((java.lang.Object) boolean46);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection48 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean49 = strComparableCollection48.isEmpty();
        boolean boolean51 = strComparableCollection48.equals((java.lang.Object) 1.0d);
        boolean boolean53 = strComparableCollection48.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection54 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean55 = strComparableCollection54.isEmpty();
        java.lang.Object[] objArray56 = strComparableCollection54.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator57 = strComparableCollection54.spliterator();
        boolean boolean58 = strComparableCollection48.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection54);
        int int59 = strComparableCollection48.size();
        java.lang.String str60 = strComparableCollection48.toString();
        boolean boolean61 = strComparableCollection30.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection48);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor62 = strComparableCollection30.iterator();
        boolean boolean63 = strComparableCollection0.equals((java.lang.Object) strComparableCollection30);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection64 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean65 = strComparableCollection64.isEmpty();
        java.lang.Object[] objArray66 = strComparableCollection64.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator67 = strComparableCollection64.spliterator();
        java.util.AbstractList[] abstractListArray69 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray70 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray69;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray71 = strComparableCollection64.toArray(strComparableListArray70);
        java.lang.Iterable<java.lang.Comparable<java.lang.String>>[] strComparableIterableArray72 = strComparableCollection0.toArray((java.lang.Iterable<java.lang.Comparable<java.lang.String>>[]) strComparableListArray71);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection73 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean74 = strComparableCollection73.isEmpty();
        boolean boolean76 = strComparableCollection73.equals((java.lang.Object) 1.0d);
        int int77 = strComparableCollection73.size();
        java.lang.String str78 = strComparableCollection73.toString();
        int int80 = strComparableCollection73.getCount((java.lang.Object) 0.0f);
        java.lang.String str81 = strComparableCollection73.toString();
        java.lang.String str82 = strComparableCollection73.toString();
        boolean boolean83 = strComparableCollection0.contains((java.lang.Object) str82);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray44), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray44), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray56), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray56), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertEquals("'" + str60 + "' != '" + "[]" + "'", str60, "[]");
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(strComparableItor62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray66), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray66), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator67);
        org.junit.Assert.assertNotNull(abstractListArray69);
        org.junit.Assert.assertNotNull(strComparableListArray70);
        org.junit.Assert.assertNotNull(strComparableListArray71);
        org.junit.Assert.assertNotNull(strComparableIterableArray72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertEquals("'" + str78 + "' != '" + "[]" + "'", str78, "[]");
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertEquals("'" + str81 + "' != '" + "[]" + "'", str81, "[]");
        org.junit.Assert.assertEquals("'" + str82 + "' != '" + "[]" + "'", str82, "[]");
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection1 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str2 = strComparableCollection1.toString();
        java.lang.Object[] objArray3 = strComparableCollection1.toArray();
        java.util.Collection[] collectionArray5 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray5;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = strComparableCollection1.toArray(strComparableCollectionArray6);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection1.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        java.lang.Object[] objArray11 = strComparableCollection9.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator12 = strComparableCollection9.spliterator();
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray16 = strComparableCollection9.toArray((java.lang.Comparable<java.lang.String>[]) strArray15);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor17 = strComparableCollection9.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        java.lang.Object[] objArray20 = strComparableCollection18.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator21 = strComparableCollection18.spliterator();
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray25 = strComparableCollection18.toArray((java.lang.Comparable<java.lang.String>[]) strArray24);
        java.lang.CharSequence[] charSequenceArray26 = strComparableCollection9.toArray((java.lang.CharSequence[]) strArray24);
        boolean boolean27 = strComparableCollection1.equals((java.lang.Object) strComparableCollection9);
        java.lang.Object[] objArray28 = strComparableCollection1.toArray();
        boolean boolean29 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
        java.lang.Class<?> wildcardClass30 = strComparableCollection1.getClass();
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(collectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray11), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray11), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strComparableArray16);
        org.junit.Assert.assertNotNull(strComparableItor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray20), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray20), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator21);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strComparableArray25);
        org.junit.Assert.assertNotNull(charSequenceArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray28), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray28), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet33 = strComparableCollection18.entrySet();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator34 = strComparableCollection18.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str36 = strComparableCollection35.toString();
        java.lang.Object[] objArray37 = strComparableCollection35.toArray();
        java.util.Collection[] collectionArray39 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray40 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray39;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray41 = strComparableCollection35.toArray(strComparableCollectionArray40);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor42 = strComparableCollection35.iterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet43 = strComparableCollection35.entrySet();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor44 = strComparableCollection35.iterator();
        boolean boolean45 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection35);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableEntrySet33);
        org.junit.Assert.assertNotNull(strComparableSpliterator34);
        org.junit.Assert.assertEquals("'" + str36 + "' != '" + "[]" + "'", str36, "[]");
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray37), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray37), "[]");
        org.junit.Assert.assertNotNull(collectionArray39);
        org.junit.Assert.assertNotNull(strComparableCollectionArray40);
        org.junit.Assert.assertNotNull(strComparableCollectionArray41);
        org.junit.Assert.assertNotNull(strComparableItor42);
        org.junit.Assert.assertNotNull(strComparableEntrySet43);
        org.junit.Assert.assertNotNull(strComparableItor44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.parallelStream();
        java.lang.Object[] objArray5 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        boolean boolean7 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        boolean boolean24 = strComparableCollection0.equals((java.lang.Object) (short) -1);
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.lang.Object[] objArray6 = strComparableCollection3.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str8 = strComparableCollection7.toString();
        java.lang.Object[] objArray9 = strComparableCollection7.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray17 = strComparableCollection10.toArray((java.lang.Comparable<java.lang.String>[]) strArray16);
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList21 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean23 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean24 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream25 = strComparableList21.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableList21.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection27 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str28 = strComparableCollection27.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection29 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean30 = strComparableCollection29.isEmpty();
        boolean boolean32 = strComparableCollection29.equals((java.lang.Object) 1.0d);
        boolean boolean34 = strComparableCollection29.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        boolean boolean38 = strComparableCollection35.equals((java.lang.Object) 1.0d);
        int int39 = strComparableCollection35.size();
        java.lang.String str40 = strComparableCollection35.toString();
        java.util.Collection[] collectionArray42 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray43 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray42;
        strComparableCollectionArray43[0] = strComparableCollection29;
        strComparableCollectionArray43[1] = strComparableCollection35;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray48 = strComparableCollection27.toArray(strComparableCollectionArray43);
        java.lang.Cloneable[] cloneableArray49 = new java.lang.Cloneable[] { objArray6, objArray9, strComparableArray17, strComparableList21, strComparableCollectionArray43 };
        java.lang.Cloneable[] cloneableArray50 = strComparableCollection0.toArray(cloneableArray49);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream51 = strComparableCollection0.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strComparableArray17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strComparableStream25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "[]" + "'", str28, "[]");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "[]" + "'", str40, "[]");
        org.junit.Assert.assertNotNull(collectionArray42);
        org.junit.Assert.assertNotNull(strComparableCollectionArray43);
        org.junit.Assert.assertNotNull(strComparableCollectionArray48);
        org.junit.Assert.assertNotNull(cloneableArray49);
        org.junit.Assert.assertNotNull(cloneableArray50);
        org.junit.Assert.assertNotNull(strComparableStream51);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean4 = strComparableCollection0.isEmpty();
        java.lang.String str5 = strComparableCollection0.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection32 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean33 = strComparableCollection32.isEmpty();
        java.lang.Object[] objArray34 = strComparableCollection32.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream35 = strComparableCollection32.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream36 = strComparableCollection32.stream();
        // The following exception was thrown during execution in test generation
        try {
            int int38 = strComparableCollection0.remove((java.lang.Object) strComparableCollection32, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray34), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray34), "[]");
        org.junit.Assert.assertNotNull(strComparableStream35);
        org.junit.Assert.assertNotNull(strComparableStream36);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        java.lang.CharSequence[][] charSequenceArray32 = new java.lang.CharSequence[][] {};
        java.lang.CharSequence[][] charSequenceArray33 = strComparableCollection4.toArray(charSequenceArray32);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator34 = strComparableCollection4.spliterator();
        int int35 = strComparableCollection4.size();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
        org.junit.Assert.assertNotNull(strComparableSpliterator34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        java.lang.String str9 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        int int14 = strComparableCollection10.size();
        java.lang.String str15 = strComparableCollection10.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str17 = strComparableCollection16.toString();
        java.lang.Object[] objArray18 = strComparableCollection16.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet19 = strComparableCollection16.uniqueSet();
        boolean boolean20 = strComparableCollection10.contains((java.lang.Object) strComparableCollection16);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream21 = strComparableCollection10.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            int int23 = strComparableCollection0.remove((java.lang.Object) strComparableCollection10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "[]" + "'", str15, "[]");
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray18), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray18), "[]");
        org.junit.Assert.assertNotNull(strComparableSet19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strComparableStream21);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Cloneable> cloneableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Cloneable>();
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet7 = strComparableCollection0.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        boolean boolean30 = strComparableCollection0.contains((java.lang.Object) strComparableCollectionArray29);
        java.lang.Class<?> wildcardClass31 = strComparableCollectionArray29.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableEntrySet7);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(strComparableSet8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean5 = strComparableCollection0.equals((java.lang.Object) (byte) 0);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean8 = strComparableCollection7.isEmpty();
        boolean boolean10 = strComparableCollection7.equals((java.lang.Object) 1.0d);
        boolean boolean12 = strComparableCollection7.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        boolean boolean16 = strComparableCollection13.equals((java.lang.Object) 1.0d);
        int int17 = strComparableCollection13.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str19 = strComparableCollection18.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection20 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean21 = strComparableCollection20.isEmpty();
        boolean boolean23 = strComparableCollection20.equals((java.lang.Object) 1.0d);
        boolean boolean25 = strComparableCollection20.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection26 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean27 = strComparableCollection26.isEmpty();
        boolean boolean29 = strComparableCollection26.equals((java.lang.Object) 1.0d);
        int int30 = strComparableCollection26.size();
        java.lang.String str31 = strComparableCollection26.toString();
        java.util.Collection[] collectionArray33 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray34 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray33;
        strComparableCollectionArray34[0] = strComparableCollection20;
        strComparableCollectionArray34[1] = strComparableCollection26;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray39 = strComparableCollection18.toArray(strComparableCollectionArray34);
        java.util.Collection[] collectionArray41 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray42 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray41;
        java.util.Collection[][] collectionArray44 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray45 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray44;
        strComparableCollectionArray45[0] = collectionArray41;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray48 = strComparableCollection18.toArray(strComparableCollectionArray45);
        java.lang.Object[][] objArray49 = strComparableCollection13.toArray((java.lang.Object[][]) strComparableCollectionArray45);
        boolean boolean50 = strComparableCollection7.contains((java.lang.Object) strComparableCollection13);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection51 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str52 = strComparableCollection51.toString();
        java.lang.Object[] objArray53 = strComparableCollection51.toArray();
        java.util.Collection[] collectionArray55 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray56 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray55;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray57 = strComparableCollection51.toArray(strComparableCollectionArray56);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet58 = strComparableCollection51.entrySet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet59 = strComparableCollection51.uniqueSet();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet60 = strComparableCollection51.uniqueSet();
        int int61 = strComparableCollection13.getCount((java.lang.Object) strComparableCollection51);
        boolean boolean62 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection51);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertEquals("'" + str19 + "' != '" + "[]" + "'", str19, "[]");
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "[]" + "'", str31, "[]");
        org.junit.Assert.assertNotNull(collectionArray33);
        org.junit.Assert.assertNotNull(strComparableCollectionArray34);
        org.junit.Assert.assertNotNull(strComparableCollectionArray39);
        org.junit.Assert.assertNotNull(collectionArray41);
        org.junit.Assert.assertNotNull(strComparableCollectionArray42);
        org.junit.Assert.assertNotNull(collectionArray44);
        org.junit.Assert.assertNotNull(strComparableCollectionArray45);
        org.junit.Assert.assertNotNull(strComparableCollectionArray48);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertEquals("'" + str52 + "' != '" + "[]" + "'", str52, "[]");
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray53), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray53), "[]");
        org.junit.Assert.assertNotNull(collectionArray55);
        org.junit.Assert.assertNotNull(strComparableCollectionArray56);
        org.junit.Assert.assertNotNull(strComparableCollectionArray57);
        org.junit.Assert.assertNotNull(strComparableEntrySet58);
        org.junit.Assert.assertNotNull(strComparableSet59);
        org.junit.Assert.assertNotNull(strComparableSet60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet7 = strComparableCollection0.entrySet();
        java.lang.Class<?> wildcardClass8 = strComparableEntrySet7.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableEntrySet7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        boolean boolean18 = strComparableCollection15.equals((java.lang.Object) 1.0d);
        boolean boolean20 = strComparableCollection15.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        boolean boolean24 = strComparableCollection21.equals((java.lang.Object) 1.0d);
        int int25 = strComparableCollection21.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection26 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str27 = strComparableCollection26.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection28 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean29 = strComparableCollection28.isEmpty();
        boolean boolean31 = strComparableCollection28.equals((java.lang.Object) 1.0d);
        boolean boolean33 = strComparableCollection28.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection34 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean35 = strComparableCollection34.isEmpty();
        boolean boolean37 = strComparableCollection34.equals((java.lang.Object) 1.0d);
        int int38 = strComparableCollection34.size();
        java.lang.String str39 = strComparableCollection34.toString();
        java.util.Collection[] collectionArray41 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray42 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray41;
        strComparableCollectionArray42[0] = strComparableCollection28;
        strComparableCollectionArray42[1] = strComparableCollection34;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray47 = strComparableCollection26.toArray(strComparableCollectionArray42);
        java.util.Collection[] collectionArray49 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray50 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray49;
        java.util.Collection[][] collectionArray52 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray53 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray52;
        strComparableCollectionArray53[0] = collectionArray49;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray56 = strComparableCollection26.toArray(strComparableCollectionArray53);
        java.lang.Object[][] objArray57 = strComparableCollection21.toArray((java.lang.Object[][]) strComparableCollectionArray53);
        boolean boolean58 = strComparableCollection15.contains((java.lang.Object) strComparableCollection21);
        java.lang.String str59 = strComparableCollection21.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean60 = strComparableCollection10.removeAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection21);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "[]" + "'", str27, "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "[]" + "'", str39, "[]");
        org.junit.Assert.assertNotNull(collectionArray41);
        org.junit.Assert.assertNotNull(strComparableCollectionArray42);
        org.junit.Assert.assertNotNull(strComparableCollectionArray47);
        org.junit.Assert.assertNotNull(collectionArray49);
        org.junit.Assert.assertNotNull(strComparableCollectionArray50);
        org.junit.Assert.assertNotNull(collectionArray52);
        org.junit.Assert.assertNotNull(strComparableCollectionArray53);
        org.junit.Assert.assertNotNull(strComparableCollectionArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertEquals("'" + str59 + "' != '" + "[]" + "'", str59, "[]");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        int int9 = strComparableCollection0.getCount((java.lang.Object) 0L);
        java.lang.String str10 = strComparableCollection0.toString();
        java.lang.String str11 = strComparableCollection0.toString();
        int int12 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertEquals("'" + str10 + "' != '" + "[]" + "'", str10, "[]");
        org.junit.Assert.assertEquals("'" + str11 + "' != '" + "[]" + "'", str11, "[]");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        br.com.unicamp.mo409.UnmodifiableMultiSet<org.apache.commons.collections4.multiset.AbstractMultiSetDecorator<java.lang.Comparable<java.lang.String>>> strComparableCollectionCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<org.apache.commons.collections4.multiset.AbstractMultiSetDecorator<java.lang.Comparable<java.lang.String>>>();
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        boolean boolean5 = strComparableCollection0.equals((java.lang.Object) (byte) 0);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet11 = strComparableCollection8.uniqueSet();
        boolean boolean12 = strComparableCollection7.equals((java.lang.Object) strComparableCollection8);
        boolean boolean13 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSet11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor4 = strComparableCollection0.iterator();
        int int5 = strComparableCollection0.size();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertNotNull(strComparableItor4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        boolean boolean15 = strComparableCollection12.equals((java.lang.Object) 1.0d);
        int int16 = strComparableCollection12.size();
        java.lang.String str17 = strComparableCollection12.toString();
        java.util.Collection[] collectionArray19 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray20 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray19;
        strComparableCollectionArray20[0] = strComparableCollection6;
        strComparableCollectionArray20[1] = strComparableCollection12;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray25 = strComparableCollection4.toArray(strComparableCollectionArray20);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableCollection4.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream27 = strComparableCollection4.stream();
        int int28 = strComparableCollection0.getCount((java.lang.Object) strComparableStream27);
        boolean boolean29 = strComparableCollection0.isEmpty();
        java.lang.Object obj30 = null;
        boolean boolean31 = strComparableCollection0.equals(obj30);
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
        org.junit.Assert.assertNotNull(collectionArray19);
        org.junit.Assert.assertNotNull(strComparableCollectionArray20);
        org.junit.Assert.assertNotNull(strComparableCollectionArray25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertNotNull(strComparableStream27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet8 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strComparableEntrySet8);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        boolean boolean15 = strComparableCollection12.equals((java.lang.Object) 1.0d);
        int int16 = strComparableCollection12.size();
        java.lang.String str17 = strComparableCollection12.toString();
        java.util.Collection[] collectionArray19 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray20 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray19;
        strComparableCollectionArray20[0] = strComparableCollection6;
        strComparableCollectionArray20[1] = strComparableCollection12;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray25 = strComparableCollection4.toArray(strComparableCollectionArray20);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableCollection4.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream27 = strComparableCollection4.stream();
        int int28 = strComparableCollection0.getCount((java.lang.Object) strComparableStream27);
        boolean boolean29 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection30 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean31 = strComparableCollection30.isEmpty();
        boolean boolean33 = strComparableCollection30.equals((java.lang.Object) 1.0d);
        boolean boolean35 = strComparableCollection30.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection36 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean37 = strComparableCollection36.isEmpty();
        java.lang.Object[] objArray38 = strComparableCollection36.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator39 = strComparableCollection36.spliterator();
        boolean boolean40 = strComparableCollection30.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection36);
        int int41 = strComparableCollection30.size();
        java.lang.String str42 = strComparableCollection30.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet43 = strComparableCollection30.entrySet();
        int int44 = strComparableCollection30.size();
        boolean boolean45 = strComparableCollection30.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection46 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean47 = strComparableCollection46.isEmpty();
        boolean boolean49 = strComparableCollection46.equals((java.lang.Object) 1.0d);
        boolean boolean51 = strComparableCollection46.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection52 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean53 = strComparableCollection52.isEmpty();
        java.lang.Object[] objArray54 = strComparableCollection52.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator55 = strComparableCollection52.spliterator();
        boolean boolean56 = strComparableCollection46.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection52);
        int int57 = strComparableCollection46.size();
        java.lang.String str58 = strComparableCollection46.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream59 = strComparableCollection46.parallelStream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet60 = strComparableCollection46.uniqueSet();
        int int61 = strComparableCollection30.getCount((java.lang.Object) strComparableCollection46);
        boolean boolean62 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection46);
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
        org.junit.Assert.assertNotNull(collectionArray19);
        org.junit.Assert.assertNotNull(strComparableCollectionArray20);
        org.junit.Assert.assertNotNull(strComparableCollectionArray25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertNotNull(strComparableStream27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray38), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray38), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "[]" + "'", str42, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray54), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray54), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertEquals("'" + str58 + "' != '" + "[]" + "'", str58, "[]");
        org.junit.Assert.assertNotNull(strComparableStream59);
        org.junit.Assert.assertNotNull(strComparableSet60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection10.spliterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str9 = strComparableCollection8.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        int int20 = strComparableCollection16.size();
        java.lang.String str21 = strComparableCollection16.toString();
        java.util.Collection[] collectionArray23 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray24 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray23;
        strComparableCollectionArray24[0] = strComparableCollection10;
        strComparableCollectionArray24[1] = strComparableCollection16;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray29 = strComparableCollection8.toArray(strComparableCollectionArray24);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection8.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream31 = strComparableCollection8.stream();
        int int32 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection8);
        java.lang.Object[] objArray33 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection34 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean35 = strComparableCollection34.isEmpty();
        java.lang.Object[] objArray36 = strComparableCollection34.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator37 = strComparableCollection34.spliterator();
        java.lang.String[] strArray40 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray41 = strComparableCollection34.toArray((java.lang.Comparable<java.lang.String>[]) strArray40);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor42 = strComparableCollection34.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection43 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean44 = strComparableCollection43.isEmpty();
        java.lang.Object[] objArray45 = strComparableCollection43.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator46 = strComparableCollection43.spliterator();
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray50 = strComparableCollection43.toArray((java.lang.Comparable<java.lang.String>[]) strArray49);
        java.lang.CharSequence[] charSequenceArray51 = strComparableCollection34.toArray((java.lang.CharSequence[]) strArray49);
        java.lang.CharSequence[] charSequenceArray52 = strComparableCollection0.toArray(charSequenceArray51);
        boolean boolean53 = strComparableCollection0.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str9 + "' != '" + "[]" + "'", str9, "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertEquals("'" + str21 + "' != '" + "[]" + "'", str21, "[]");
        org.junit.Assert.assertNotNull(collectionArray23);
        org.junit.Assert.assertNotNull(strComparableCollectionArray24);
        org.junit.Assert.assertNotNull(strComparableCollectionArray29);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertNotNull(strComparableStream31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray33), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray33), "[]");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray36), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray36), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator37);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(strComparableArray41);
        org.junit.Assert.assertNotNull(strComparableItor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray45), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray45), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator46);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(strComparableArray50);
        org.junit.Assert.assertNotNull(charSequenceArray51);
        org.junit.Assert.assertNotNull(charSequenceArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean10 = strComparableCollection8.isEmpty();
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String[] strArray12 = strComparableCollection8.toArray(strArray11);
        boolean boolean13 = strComparableCollection0.contains((java.lang.Object) strArray12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        java.lang.Object[] objArray10 = strComparableCollection8.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection8.spliterator();
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray15 = strComparableCollection8.toArray((java.lang.Comparable<java.lang.String>[]) strArray14);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor16 = strComparableCollection8.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection17 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean18 = strComparableCollection17.isEmpty();
        java.lang.Object[] objArray19 = strComparableCollection17.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator20 = strComparableCollection17.spliterator();
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray24 = strComparableCollection17.toArray((java.lang.Comparable<java.lang.String>[]) strArray23);
        java.lang.CharSequence[] charSequenceArray25 = strComparableCollection8.toArray((java.lang.CharSequence[]) strArray23);
        boolean boolean26 = strComparableCollection0.equals((java.lang.Object) strComparableCollection8);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor27 = strComparableCollection8.iterator();
        boolean boolean28 = strComparableCollection8.isEmpty();
        java.lang.String str29 = strComparableCollection8.toString();
        java.lang.Class<?> wildcardClass30 = strComparableCollection8.getClass();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray10), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray10), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strComparableArray15);
        org.junit.Assert.assertNotNull(strComparableItor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray19), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray19), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator20);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strComparableArray24);
        org.junit.Assert.assertNotNull(charSequenceArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(strComparableItor27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "[]" + "'", str29, "[]");
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream1 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str3 = strComparableCollection2.toString();
        java.lang.Object[] objArray4 = strComparableCollection2.toArray();
        java.util.Collection[] collectionArray6 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray7 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray6;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray8 = strComparableCollection2.toArray(strComparableCollectionArray7);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection2.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass11 = strComparableListCollection10.getClass();
        java.lang.reflect.Type[] typeArray12 = new java.lang.reflect.Type[] { wildcardClass11 };
        java.lang.reflect.Type[] typeArray13 = strComparableCollection2.toArray(typeArray12);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection2.iterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet15 = strComparableCollection2.uniqueSet();
        java.lang.Object[] objArray16 = strComparableCollection2.toArray();
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) strComparableCollection2);
        org.junit.Assert.assertNotNull(strComparableStream1);
        org.junit.Assert.assertEquals("'" + str3 + "' != '" + "[]" + "'", str3, "[]");
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray4), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray4), "[]");
        org.junit.Assert.assertNotNull(collectionArray6);
        org.junit.Assert.assertNotNull(strComparableCollectionArray7);
        org.junit.Assert.assertNotNull(strComparableCollectionArray8);
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(typeArray12);
        org.junit.Assert.assertNotNull(typeArray13);
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableSet15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray16), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray16), "[]");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.Set<java.lang.Comparable<java.lang.String>>> strComparableSetCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.Set<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass1 = strComparableSetCollection0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.lang.String str14 = strComparableCollection0.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "[]" + "'", str14, "[]");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        boolean boolean18 = strComparableCollection15.equals((java.lang.Object) 1.0d);
        boolean boolean20 = strComparableCollection15.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        boolean boolean25 = strComparableCollection15.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection21);
        int int26 = strComparableCollection15.size();
        java.lang.String str27 = strComparableCollection15.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet28 = strComparableCollection15.entrySet();
        int int29 = strComparableCollection15.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator30 = strComparableCollection15.spliterator();
        int int31 = strComparableCollection0.getCount((java.lang.Object) strComparableSpliterator30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertEquals("'" + str27 + "' != '" + "[]" + "'", str27, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        java.lang.Object[] objArray15 = strComparableCollection0.toArray();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray15), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray15), "[]");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream32 = strComparableCollection18.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet33 = strComparableCollection18.entrySet();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet34 = strComparableCollection18.entrySet();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        boolean boolean37 = strComparableCollection35.isEmpty();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream38 = strComparableCollection35.parallelStream();
        int int39 = strComparableCollection18.getCount((java.lang.Object) strComparableStream38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableStream32);
        org.junit.Assert.assertNotNull(strComparableEntrySet33);
        org.junit.Assert.assertNotNull(strComparableEntrySet34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strComparableStream38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet8 = strComparableCollection0.entrySet();
        java.lang.Object[] objArray9 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream10 = strComparableCollection0.stream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet11 = strComparableCollection0.uniqueSet();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertNotNull(strComparableEntrySet8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
        org.junit.Assert.assertNotNull(strComparableStream10);
        org.junit.Assert.assertNotNull(strComparableSet11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.AnnotatedElement> annotatedElementCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.reflect.AnnotatedElement>();
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream7 = strComparableCollection0.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection0.spliterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableStream7);
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        boolean boolean21 = strComparableCollection16.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        java.lang.Object[] objArray24 = strComparableCollection22.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator25 = strComparableCollection22.spliterator();
        boolean boolean26 = strComparableCollection16.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection22);
        boolean boolean27 = strComparableCollection10.equals((java.lang.Object) boolean26);
        java.lang.Class<?> wildcardClass28 = strComparableCollection10.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection29 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean30 = strComparableCollection29.isEmpty();
        boolean boolean32 = strComparableCollection29.equals((java.lang.Object) 1.0d);
        boolean boolean34 = strComparableCollection29.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        java.lang.Object[] objArray37 = strComparableCollection35.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator38 = strComparableCollection35.spliterator();
        boolean boolean39 = strComparableCollection29.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection35);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet40 = strComparableCollection29.entrySet();
        java.lang.Class<?> wildcardClass41 = strComparableCollection29.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str43 = strComparableCollection42.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection44 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean45 = strComparableCollection44.isEmpty();
        boolean boolean47 = strComparableCollection44.equals((java.lang.Object) 1.0d);
        boolean boolean49 = strComparableCollection44.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection50 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean51 = strComparableCollection50.isEmpty();
        boolean boolean53 = strComparableCollection50.equals((java.lang.Object) 1.0d);
        int int54 = strComparableCollection50.size();
        java.lang.String str55 = strComparableCollection50.toString();
        java.util.Collection[] collectionArray57 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray58 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray57;
        strComparableCollectionArray58[0] = strComparableCollection44;
        strComparableCollectionArray58[1] = strComparableCollection50;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray63 = strComparableCollection42.toArray(strComparableCollectionArray58);
        java.lang.Class<?> wildcardClass64 = strComparableCollectionArray63.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection65 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str66 = strComparableCollection65.toString();
        java.lang.Object[] objArray67 = strComparableCollection65.toArray();
        java.util.Collection[] collectionArray69 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray70 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray69;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray71 = strComparableCollection65.toArray(strComparableCollectionArray70);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator72 = strComparableCollection65.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet73 = strComparableCollection65.uniqueSet();
        java.lang.Class<?> wildcardClass74 = strComparableCollection65.getClass();
        java.lang.reflect.Type[] typeArray75 = new java.lang.reflect.Type[] { wildcardClass28, wildcardClass41, wildcardClass64, wildcardClass74 };
        java.lang.reflect.Type[][] typeArray76 = new java.lang.reflect.Type[][] { typeArray75 };
        java.lang.reflect.Type[][] typeArray77 = strComparableCollection0.toArray(typeArray76);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection78 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean79 = strComparableCollection78.isEmpty();
        java.lang.Object[] objArray80 = strComparableCollection78.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator81 = strComparableCollection78.spliterator();
        java.lang.String[] strArray84 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray85 = strComparableCollection78.toArray((java.lang.Comparable<java.lang.String>[]) strArray84);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor86 = strComparableCollection78.iterator();
        boolean boolean87 = strComparableCollection0.equals((java.lang.Object) strComparableItor86);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet88 = strComparableCollection0.uniqueSet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray24), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray24), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray37), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray37), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "[]" + "'", str43, "[]");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "[]" + "'", str55, "[]");
        org.junit.Assert.assertNotNull(collectionArray57);
        org.junit.Assert.assertNotNull(strComparableCollectionArray58);
        org.junit.Assert.assertNotNull(strComparableCollectionArray63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "[]" + "'", str66, "[]");
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray67), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray67), "[]");
        org.junit.Assert.assertNotNull(collectionArray69);
        org.junit.Assert.assertNotNull(strComparableCollectionArray70);
        org.junit.Assert.assertNotNull(strComparableCollectionArray71);
        org.junit.Assert.assertNotNull(strComparableSpliterator72);
        org.junit.Assert.assertNotNull(strComparableSet73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(typeArray75);
        org.junit.Assert.assertNotNull(typeArray76);
        org.junit.Assert.assertNotNull(typeArray77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray80), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray80), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator81);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(strComparableArray85);
        org.junit.Assert.assertNotNull(strComparableItor86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(strComparableSet88);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.lang.String str14 = strComparableCollection0.toString();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean16 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "[]" + "'", str14, "[]");
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.contains((java.lang.Object) 1);
        boolean boolean13 = strComparableCollection8.contains((java.lang.Object) "[]");
        java.lang.String str14 = strComparableCollection8.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor15 = strComparableCollection8.iterator();
        int int16 = strComparableCollection8.size();
        boolean boolean17 = strComparableCollection0.contains((java.lang.Object) strComparableCollection8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "[]" + "'", str14, "[]");
        org.junit.Assert.assertNotNull(strComparableItor15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet2 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String[] strArray4 = strComparableCollection0.toArray(strArray3);
        int int5 = strComparableCollection0.size();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(strComparableStream6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        // The following exception was thrown during execution in test generation
        try {
            int int34 = strComparableCollection18.add((java.lang.Comparable<java.lang.String>) "hi!", (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        int int20 = strComparableCollection9.size();
        int int21 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection0.parallelStream();
        java.lang.String str16 = strComparableCollection0.toString();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet17 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableStream15);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(strComparableEntrySet17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        int int20 = strComparableCollection9.size();
        int int21 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream22 = strComparableCollection9.stream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(strComparableStream22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream3 = strComparableCollection0.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.stream();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet5 = strComparableCollection0.entrySet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableStream3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(strComparableEntrySet5);
        org.junit.Assert.assertNotNull(strComparableStream6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection5 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean6 = strComparableCollection5.isEmpty();
        java.lang.Object[] objArray7 = strComparableCollection5.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator8 = strComparableCollection5.spliterator();
        java.lang.String[] strArray11 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray12 = strComparableCollection5.toArray((java.lang.Comparable<java.lang.String>[]) strArray11);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection5.iterator();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableItor13);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str16 = strComparableCollection15.toString();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Collection[] collectionArray19 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray20 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray19;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection15.toArray(strComparableCollectionArray20);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor22 = strComparableCollection15.iterator();
        boolean boolean23 = strComparableCollection0.contains((java.lang.Object) strComparableItor22);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray7), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray7), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strComparableArray12);
        org.junit.Assert.assertNotNull(strComparableItor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(collectionArray19);
        org.junit.Assert.assertNotNull(strComparableCollectionArray20);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(strComparableItor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        int int11 = strComparableCollection0.size();
        java.lang.String str12 = strComparableCollection0.toString();
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor14 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream15 = strComparableCollection0.stream();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream16 = strComparableCollection0.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator17 = strComparableCollection0.spliterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(strComparableItor14);
        org.junit.Assert.assertNotNull(strComparableStream15);
        org.junit.Assert.assertNotNull(strComparableStream16);
        org.junit.Assert.assertNotNull(strComparableSpliterator17);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection2 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean3 = strComparableCollection2.isEmpty();
        boolean boolean5 = strComparableCollection2.equals((java.lang.Object) 1.0d);
        boolean boolean7 = strComparableCollection2.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean9 = strComparableCollection8.isEmpty();
        boolean boolean11 = strComparableCollection8.equals((java.lang.Object) 1.0d);
        int int12 = strComparableCollection8.size();
        java.lang.String str13 = strComparableCollection8.toString();
        java.util.Collection[] collectionArray15 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray16 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray15;
        strComparableCollectionArray16[0] = strComparableCollection2;
        strComparableCollectionArray16[1] = strComparableCollection8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray21 = strComparableCollection0.toArray(strComparableCollectionArray16);
        java.lang.Object[] objArray22 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream23 = strComparableCollection0.parallelStream();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "[]" + "'", str13, "[]");
        org.junit.Assert.assertNotNull(collectionArray15);
        org.junit.Assert.assertNotNull(strComparableCollectionArray16);
        org.junit.Assert.assertNotNull(strComparableCollectionArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray22), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray22), "[]");
        org.junit.Assert.assertNotNull(strComparableStream23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        boolean boolean7 = strComparableCollection0.equals((java.lang.Object) 10.0f);
        java.lang.Object[] objArray8 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        int int20 = strComparableCollection9.size();
        int int21 = strComparableCollection0.getCount((java.lang.Object) strComparableCollection9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator22 = strComparableCollection0.spliterator();
        java.lang.Object[] objArray23 = strComparableCollection0.toArray();
        java.lang.Object[] objArray24 = strComparableCollection0.toArray();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray24), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray24), "[]");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        java.lang.Class<?> wildcardClass8 = strComparableItor7.getClass();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        int int4 = strComparableCollection0.size();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        boolean boolean2 = strComparableCollection0.isEmpty();
        int int3 = strComparableCollection0.size();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        boolean boolean15 = strComparableCollection12.equals((java.lang.Object) 1.0d);
        int int16 = strComparableCollection12.size();
        java.lang.String str17 = strComparableCollection12.toString();
        java.util.Collection[] collectionArray19 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray20 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray19;
        strComparableCollectionArray20[0] = strComparableCollection6;
        strComparableCollectionArray20[1] = strComparableCollection12;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray25 = strComparableCollection4.toArray(strComparableCollectionArray20);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableCollection4.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream27 = strComparableCollection4.stream();
        int int28 = strComparableCollection0.getCount((java.lang.Object) strComparableStream27);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream29 = strComparableCollection0.stream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet30 = strComparableCollection0.uniqueSet();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertEquals("'" + str17 + "' != '" + "[]" + "'", str17, "[]");
        org.junit.Assert.assertNotNull(collectionArray19);
        org.junit.Assert.assertNotNull(strComparableCollectionArray20);
        org.junit.Assert.assertNotNull(strComparableCollectionArray25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertNotNull(strComparableStream27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(strComparableStream29);
        org.junit.Assert.assertNotNull(strComparableSet30);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator1 = strComparableCollection0.spliterator();
        java.lang.String str2 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator6 = strComparableCollection3.spliterator();
        java.util.AbstractList[] abstractListArray8 = new java.util.AbstractList[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray9 = (java.util.AbstractList<java.lang.Comparable<java.lang.String>>[]) abstractListArray8;
        java.util.AbstractList<java.lang.Comparable<java.lang.String>>[] strComparableListArray10 = strComparableCollection3.toArray(strComparableListArray9);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection3.stream();
        boolean boolean12 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        java.lang.Object[] objArray13 = strComparableCollection0.toArray();
        java.lang.Class<?> wildcardClass14 = objArray13.getClass();
        org.junit.Assert.assertNotNull(strComparableSpliterator1);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "[]" + "'", str2, "[]");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator6);
        org.junit.Assert.assertNotNull(abstractListArray8);
        org.junit.Assert.assertNotNull(strComparableListArray9);
        org.junit.Assert.assertNotNull(strComparableListArray10);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray13), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray13), "[]");
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor8 = strComparableCollection0.iterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.parallelStream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet10 = strComparableCollection0.uniqueSet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strComparableItor8);
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertNotNull(strComparableSet10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean4 = strComparableCollection3.isEmpty();
        boolean boolean6 = strComparableCollection3.equals((java.lang.Object) 1.0d);
        boolean boolean8 = strComparableCollection3.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection9 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean10 = strComparableCollection9.isEmpty();
        boolean boolean12 = strComparableCollection9.equals((java.lang.Object) 1.0d);
        boolean boolean14 = strComparableCollection9.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection15 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean16 = strComparableCollection15.isEmpty();
        java.lang.Object[] objArray17 = strComparableCollection15.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator18 = strComparableCollection15.spliterator();
        boolean boolean19 = strComparableCollection9.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection15);
        boolean boolean20 = strComparableCollection3.equals((java.lang.Object) boolean19);
        java.lang.Class<?> wildcardClass21 = strComparableCollection3.getClass();
        boolean boolean22 = strComparableCollection0.equals((java.lang.Object) strComparableCollection3);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection23 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean24 = strComparableCollection23.isEmpty();
        boolean boolean26 = strComparableCollection23.equals((java.lang.Object) 1.0d);
        int int27 = strComparableCollection23.size();
        java.lang.String str28 = strComparableCollection23.toString();
        int int30 = strComparableCollection23.getCount((java.lang.Object) 0.0f);
        java.lang.String str31 = strComparableCollection23.toString();
        java.lang.String str32 = strComparableCollection23.toString();
        boolean boolean33 = strComparableCollection23.isEmpty();
        boolean boolean34 = strComparableCollection3.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection23);
        // The following exception was thrown during execution in test generation
        try {
            int int37 = strComparableCollection23.setCount((java.lang.Comparable<java.lang.String>) "[]", (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "[]" + "'", str28, "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertEquals("'" + str31 + "' != '" + "[]" + "'", str31, "[]");
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "[]" + "'", str32, "[]");
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream9 = strComparableCollection0.stream();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream13 = strComparableCollection10.stream();
        boolean boolean14 = strComparableCollection0.equals((java.lang.Object) strComparableCollection10);
        // The following exception was thrown during execution in test generation
        try {
            int int17 = strComparableCollection10.setCount((java.lang.Comparable<java.lang.String>) "[]", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(strComparableStream9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableStream13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.lang.Object[] objArray3 = strComparableCollection0.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str5 = strComparableCollection4.toString();
        java.lang.Object[] objArray6 = strComparableCollection4.toArray();
        java.util.Collection[] collectionArray8 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray9 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray8;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray10 = strComparableCollection4.toArray(strComparableCollectionArray9);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator11 = strComparableCollection4.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        java.lang.String[] strArray18 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray19 = strComparableCollection12.toArray((java.lang.Comparable<java.lang.String>[]) strArray18);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor20 = strComparableCollection12.iterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection21 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableCollection21.isEmpty();
        java.lang.Object[] objArray23 = strComparableCollection21.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator24 = strComparableCollection21.spliterator();
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray28 = strComparableCollection21.toArray((java.lang.Comparable<java.lang.String>[]) strArray27);
        java.lang.CharSequence[] charSequenceArray29 = strComparableCollection12.toArray((java.lang.CharSequence[]) strArray27);
        boolean boolean30 = strComparableCollection4.equals((java.lang.Object) strComparableCollection12);
        boolean boolean31 = strComparableCollection0.contains((java.lang.Object) strComparableCollection4);
        java.lang.CharSequence[][] charSequenceArray32 = new java.lang.CharSequence[][] {};
        java.lang.CharSequence[][] charSequenceArray33 = strComparableCollection4.toArray(charSequenceArray32);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator34 = strComparableCollection4.spliterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet35 = strComparableCollection4.entrySet();
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray3), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray3), "[]");
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertNotNull(collectionArray8);
        org.junit.Assert.assertNotNull(strComparableCollectionArray9);
        org.junit.Assert.assertNotNull(strComparableCollectionArray10);
        org.junit.Assert.assertNotNull(strComparableSpliterator11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(strComparableArray19);
        org.junit.Assert.assertNotNull(strComparableItor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray23), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray23), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator24);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strComparableArray28);
        org.junit.Assert.assertNotNull(charSequenceArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(charSequenceArray32);
        org.junit.Assert.assertNotNull(charSequenceArray33);
        org.junit.Assert.assertNotNull(strComparableSpliterator34);
        org.junit.Assert.assertNotNull(strComparableEntrySet35);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection6.spliterator();
        boolean boolean10 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream11 = strComparableCollection0.parallelStream();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet12 = strComparableCollection0.uniqueSet();
        java.lang.Object obj13 = null;
        boolean boolean14 = strComparableCollection0.equals(obj13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strComparableStream11);
        org.junit.Assert.assertNotNull(strComparableSet12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str7 = strComparableCollection6.toString();
        java.lang.Object[] objArray8 = strComparableCollection6.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet9 = strComparableCollection6.uniqueSet();
        boolean boolean10 = strComparableCollection0.contains((java.lang.Object) strComparableCollection6);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection11 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str12 = strComparableCollection11.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection13 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean14 = strComparableCollection13.isEmpty();
        boolean boolean16 = strComparableCollection13.equals((java.lang.Object) 1.0d);
        boolean boolean18 = strComparableCollection13.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        boolean boolean22 = strComparableCollection19.equals((java.lang.Object) 1.0d);
        int int23 = strComparableCollection19.size();
        java.lang.String str24 = strComparableCollection19.toString();
        java.util.Collection[] collectionArray26 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray27 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray26;
        strComparableCollectionArray27[0] = strComparableCollection13;
        strComparableCollectionArray27[1] = strComparableCollection19;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray32 = strComparableCollection11.toArray(strComparableCollectionArray27);
        java.util.Collection[] collectionArray34 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray35 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray34;
        java.util.Collection[][] collectionArray37 = new java.util.Collection[1][];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray38 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[][]) collectionArray37;
        strComparableCollectionArray38[0] = collectionArray34;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[][] strComparableCollectionArray41 = strComparableCollection11.toArray(strComparableCollectionArray38);
        int int42 = strComparableCollection6.getCount((java.lang.Object) strComparableCollection11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "[]" + "'", str7, "[]");
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray8), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray8), "[]");
        org.junit.Assert.assertNotNull(strComparableSet9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals("'" + str24 + "' != '" + "[]" + "'", str24, "[]");
        org.junit.Assert.assertNotNull(collectionArray26);
        org.junit.Assert.assertNotNull(strComparableCollectionArray27);
        org.junit.Assert.assertNotNull(strComparableCollectionArray32);
        org.junit.Assert.assertNotNull(collectionArray34);
        org.junit.Assert.assertNotNull(strComparableCollectionArray35);
        org.junit.Assert.assertNotNull(collectionArray37);
        org.junit.Assert.assertNotNull(strComparableCollectionArray38);
        org.junit.Assert.assertNotNull(strComparableCollectionArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator7 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>> strComparableListCollection8 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.util.AbstractList<java.lang.Comparable<java.lang.String>>>();
        java.lang.Class<?> wildcardClass9 = strComparableListCollection8.getClass();
        java.lang.reflect.Type[] typeArray10 = new java.lang.reflect.Type[] { wildcardClass9 };
        java.lang.reflect.Type[] typeArray11 = strComparableCollection0.toArray(typeArray10);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor12 = strComparableCollection0.iterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet13 = strComparableCollection0.uniqueSet();
        java.lang.Object[] objArray14 = strComparableCollection0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableSpliterator7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(typeArray10);
        org.junit.Assert.assertNotNull(typeArray11);
        org.junit.Assert.assertNotNull(strComparableItor12);
        org.junit.Assert.assertNotNull(strComparableSet13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet3 = strComparableCollection0.uniqueSet();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream4 = strComparableCollection0.parallelStream();
        java.lang.Object[] objArray5 = strComparableCollection0.toArray();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream6 = strComparableCollection0.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            int int9 = strComparableCollection0.add((java.lang.Comparable<java.lang.String>) "[]", (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSet3);
        org.junit.Assert.assertNotNull(strComparableStream4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(strComparableStream6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet8 = strComparableCollection0.entrySet();
        java.lang.Comparable<java.lang.String> strComparable9 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int11 = strComparableCollection0.setCount(strComparable9, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertNotNull(strComparableEntrySet8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator4 = strComparableCollection0.spliterator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strComparableSpliterator4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.String str5 = strComparableCollection0.toString();
        int int7 = strComparableCollection0.getCount((java.lang.Object) 0.0f);
        java.lang.String str8 = strComparableCollection0.toString();
        java.lang.CharSequence[] charSequenceArray10 = new java.lang.CharSequence[] { "[]" };
        java.lang.CharSequence[] charSequenceArray12 = new java.lang.CharSequence[] { "[]" };
        java.lang.CharSequence[] charSequenceArray14 = new java.lang.CharSequence[] { "[]" };
        java.lang.CharSequence[] charSequenceArray16 = new java.lang.CharSequence[] { "[]" };
        java.lang.CharSequence[] charSequenceArray18 = new java.lang.CharSequence[] { "[]" };
        java.lang.CharSequence[][] charSequenceArray19 = new java.lang.CharSequence[][] { charSequenceArray10, charSequenceArray12, charSequenceArray14, charSequenceArray16, charSequenceArray18 };
        java.lang.CharSequence[][][] charSequenceArray20 = new java.lang.CharSequence[][][] { charSequenceArray19 };
        java.lang.CharSequence[][][] charSequenceArray21 = strComparableCollection0.toArray(charSequenceArray20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "[]" + "'", str5, "[]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(charSequenceArray10);
        org.junit.Assert.assertNotNull(charSequenceArray12);
        org.junit.Assert.assertNotNull(charSequenceArray14);
        org.junit.Assert.assertNotNull(charSequenceArray16);
        org.junit.Assert.assertNotNull(charSequenceArray18);
        org.junit.Assert.assertNotNull(charSequenceArray19);
        org.junit.Assert.assertNotNull(charSequenceArray20);
        org.junit.Assert.assertNotNull(charSequenceArray21);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.equals((java.lang.Object) 1.0d);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection12 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean13 = strComparableCollection12.isEmpty();
        java.lang.Object[] objArray14 = strComparableCollection12.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection12.spliterator();
        boolean boolean16 = strComparableCollection6.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection12);
        boolean boolean17 = strComparableCollection0.equals((java.lang.Object) boolean16);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection18 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean19 = strComparableCollection18.isEmpty();
        boolean boolean21 = strComparableCollection18.equals((java.lang.Object) 1.0d);
        boolean boolean23 = strComparableCollection18.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection24 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean25 = strComparableCollection24.isEmpty();
        java.lang.Object[] objArray26 = strComparableCollection24.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator27 = strComparableCollection24.spliterator();
        boolean boolean28 = strComparableCollection18.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection24);
        int int29 = strComparableCollection18.size();
        java.lang.String str30 = strComparableCollection18.toString();
        boolean boolean31 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection18);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet32 = strComparableCollection18.entrySet();
        // The following exception was thrown during execution in test generation
        try {
            int int35 = strComparableCollection18.add((java.lang.Comparable<java.lang.String>) "[]", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray26), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray26), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertEquals("'" + str30 + "' != '" + "[]" + "'", str30, "[]");
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet32);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection19 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean20 = strComparableCollection19.isEmpty();
        boolean boolean22 = strComparableCollection19.equals((java.lang.Object) 1.0d);
        boolean boolean24 = strComparableCollection19.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection25 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean26 = strComparableCollection25.isEmpty();
        java.lang.Object[] objArray27 = strComparableCollection25.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator28 = strComparableCollection25.spliterator();
        boolean boolean29 = strComparableCollection19.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection25);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet30 = strComparableCollection19.entrySet();
        boolean boolean31 = strComparableCollection4.contains((java.lang.Object) strComparableEntrySet30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray27), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray27), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        int int4 = strComparableCollection0.size();
        java.lang.Object[] objArray5 = strComparableCollection0.toArray();
        int int6 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator3 = strComparableCollection0.spliterator();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray7 = strComparableCollection0.toArray((java.lang.Comparable<java.lang.String>[]) strArray6);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor8 = strComparableCollection0.iterator();
        java.lang.Object[] objArray9 = strComparableCollection0.toArray();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strComparableArray7);
        org.junit.Assert.assertNotNull(strComparableItor8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) "[]");
        java.lang.String str6 = strComparableCollection0.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        int int8 = strComparableCollection0.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator9 = strComparableCollection0.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        boolean boolean13 = strComparableCollection10.equals((java.lang.Object) 1.0d);
        boolean boolean15 = strComparableCollection10.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        boolean boolean21 = strComparableCollection16.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        java.lang.Object[] objArray24 = strComparableCollection22.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator25 = strComparableCollection22.spliterator();
        boolean boolean26 = strComparableCollection16.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection22);
        boolean boolean27 = strComparableCollection10.equals((java.lang.Object) boolean26);
        java.lang.Class<?> wildcardClass28 = strComparableCollection10.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection29 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean30 = strComparableCollection29.isEmpty();
        boolean boolean32 = strComparableCollection29.equals((java.lang.Object) 1.0d);
        boolean boolean34 = strComparableCollection29.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        java.lang.Object[] objArray37 = strComparableCollection35.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator38 = strComparableCollection35.spliterator();
        boolean boolean39 = strComparableCollection29.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection35);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet40 = strComparableCollection29.entrySet();
        java.lang.Class<?> wildcardClass41 = strComparableCollection29.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection42 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str43 = strComparableCollection42.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection44 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean45 = strComparableCollection44.isEmpty();
        boolean boolean47 = strComparableCollection44.equals((java.lang.Object) 1.0d);
        boolean boolean49 = strComparableCollection44.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection50 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean51 = strComparableCollection50.isEmpty();
        boolean boolean53 = strComparableCollection50.equals((java.lang.Object) 1.0d);
        int int54 = strComparableCollection50.size();
        java.lang.String str55 = strComparableCollection50.toString();
        java.util.Collection[] collectionArray57 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray58 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray57;
        strComparableCollectionArray58[0] = strComparableCollection44;
        strComparableCollectionArray58[1] = strComparableCollection50;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray63 = strComparableCollection42.toArray(strComparableCollectionArray58);
        java.lang.Class<?> wildcardClass64 = strComparableCollectionArray63.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection65 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str66 = strComparableCollection65.toString();
        java.lang.Object[] objArray67 = strComparableCollection65.toArray();
        java.util.Collection[] collectionArray69 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray70 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray69;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray71 = strComparableCollection65.toArray(strComparableCollectionArray70);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator72 = strComparableCollection65.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet73 = strComparableCollection65.uniqueSet();
        java.lang.Class<?> wildcardClass74 = strComparableCollection65.getClass();
        java.lang.reflect.Type[] typeArray75 = new java.lang.reflect.Type[] { wildcardClass28, wildcardClass41, wildcardClass64, wildcardClass74 };
        java.lang.reflect.Type[][] typeArray76 = new java.lang.reflect.Type[][] { typeArray75 };
        java.lang.reflect.Type[][] typeArray77 = strComparableCollection0.toArray(typeArray76);
        boolean boolean78 = strComparableCollection0.isEmpty();
        int int79 = strComparableCollection0.size();
        int int80 = strComparableCollection0.size();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "[]" + "'", str6, "[]");
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray24), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray24), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray37), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray37), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "[]" + "'", str43, "[]");
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertEquals("'" + str55 + "' != '" + "[]" + "'", str55, "[]");
        org.junit.Assert.assertNotNull(collectionArray57);
        org.junit.Assert.assertNotNull(strComparableCollectionArray58);
        org.junit.Assert.assertNotNull(strComparableCollectionArray63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertEquals("'" + str66 + "' != '" + "[]" + "'", str66, "[]");
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray67), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray67), "[]");
        org.junit.Assert.assertNotNull(collectionArray69);
        org.junit.Assert.assertNotNull(strComparableCollectionArray70);
        org.junit.Assert.assertNotNull(strComparableCollectionArray71);
        org.junit.Assert.assertNotNull(strComparableSpliterator72);
        org.junit.Assert.assertNotNull(strComparableSet73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(typeArray75);
        org.junit.Assert.assertNotNull(typeArray76);
        org.junit.Assert.assertNotNull(typeArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean2 = strComparableCollection0.isEmpty();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection3 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str4 = strComparableCollection3.toString();
        java.lang.Object[] objArray5 = strComparableCollection3.toArray();
        java.lang.Object[] objArray6 = strComparableCollection3.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection7 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str8 = strComparableCollection7.toString();
        java.lang.Object[] objArray9 = strComparableCollection7.toArray();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        java.lang.String[] strArray16 = new java.lang.String[] { "hi!", "[]" };
        java.lang.Comparable<java.lang.String>[] strComparableArray17 = strComparableCollection10.toArray((java.lang.Comparable<java.lang.String>[]) strArray16);
        java.util.ArrayList<java.lang.Comparable<java.lang.String>> strComparableList21 = new java.util.ArrayList<java.lang.Comparable<java.lang.String>>();
        boolean boolean22 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean23 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "[]");
        boolean boolean24 = strComparableList21.add((java.lang.Comparable<java.lang.String>) "hi!");
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream25 = strComparableList21.parallelStream();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator26 = strComparableList21.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection27 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str28 = strComparableCollection27.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection29 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean30 = strComparableCollection29.isEmpty();
        boolean boolean32 = strComparableCollection29.equals((java.lang.Object) 1.0d);
        boolean boolean34 = strComparableCollection29.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        boolean boolean38 = strComparableCollection35.equals((java.lang.Object) 1.0d);
        int int39 = strComparableCollection35.size();
        java.lang.String str40 = strComparableCollection35.toString();
        java.util.Collection[] collectionArray42 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray43 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray42;
        strComparableCollectionArray43[0] = strComparableCollection29;
        strComparableCollectionArray43[1] = strComparableCollection35;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray48 = strComparableCollection27.toArray(strComparableCollectionArray43);
        java.lang.Cloneable[] cloneableArray49 = new java.lang.Cloneable[] { objArray6, objArray9, strComparableArray17, strComparableList21, strComparableCollectionArray43 };
        java.lang.Cloneable[] cloneableArray50 = strComparableCollection0.toArray(cloneableArray49);
        boolean boolean51 = strComparableCollection0.isEmpty();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet52 = strComparableCollection0.entrySet();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "[]" + "'", str4, "[]");
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray5), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray5), "[]");
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray6), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray6), "[]");
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "[]" + "'", str8, "[]");
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray9), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray9), "[]");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strComparableArray17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strComparableStream25);
        org.junit.Assert.assertNotNull(strComparableSpliterator26);
        org.junit.Assert.assertEquals("'" + str28 + "' != '" + "[]" + "'", str28, "[]");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertEquals("'" + str40 + "' != '" + "[]" + "'", str40, "[]");
        org.junit.Assert.assertNotNull(collectionArray42);
        org.junit.Assert.assertNotNull(strComparableCollectionArray43);
        org.junit.Assert.assertNotNull(strComparableCollectionArray48);
        org.junit.Assert.assertNotNull(cloneableArray49);
        org.junit.Assert.assertNotNull(cloneableArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet52);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.equals((java.lang.Object) 1.0d);
        boolean boolean5 = strComparableCollection0.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection6 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean7 = strComparableCollection6.isEmpty();
        boolean boolean9 = strComparableCollection6.contains((java.lang.Object) 1);
        boolean boolean11 = strComparableCollection6.contains((java.lang.Object) "[]");
        java.lang.String str12 = strComparableCollection6.toString();
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor13 = strComparableCollection6.iterator();
        int int14 = strComparableCollection6.size();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator15 = strComparableCollection6.spliterator();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection16 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean17 = strComparableCollection16.isEmpty();
        boolean boolean19 = strComparableCollection16.equals((java.lang.Object) 1.0d);
        boolean boolean21 = strComparableCollection16.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection22 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean23 = strComparableCollection22.isEmpty();
        boolean boolean25 = strComparableCollection22.equals((java.lang.Object) 1.0d);
        boolean boolean27 = strComparableCollection22.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection28 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean29 = strComparableCollection28.isEmpty();
        java.lang.Object[] objArray30 = strComparableCollection28.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator31 = strComparableCollection28.spliterator();
        boolean boolean32 = strComparableCollection22.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection28);
        boolean boolean33 = strComparableCollection16.equals((java.lang.Object) boolean32);
        java.lang.Class<?> wildcardClass34 = strComparableCollection16.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection35 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean36 = strComparableCollection35.isEmpty();
        boolean boolean38 = strComparableCollection35.equals((java.lang.Object) 1.0d);
        boolean boolean40 = strComparableCollection35.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection41 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean42 = strComparableCollection41.isEmpty();
        java.lang.Object[] objArray43 = strComparableCollection41.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator44 = strComparableCollection41.spliterator();
        boolean boolean45 = strComparableCollection35.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection41);
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet46 = strComparableCollection35.entrySet();
        java.lang.Class<?> wildcardClass47 = strComparableCollection35.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection48 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str49 = strComparableCollection48.toString();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection50 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean51 = strComparableCollection50.isEmpty();
        boolean boolean53 = strComparableCollection50.equals((java.lang.Object) 1.0d);
        boolean boolean55 = strComparableCollection50.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection56 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean57 = strComparableCollection56.isEmpty();
        boolean boolean59 = strComparableCollection56.equals((java.lang.Object) 1.0d);
        int int60 = strComparableCollection56.size();
        java.lang.String str61 = strComparableCollection56.toString();
        java.util.Collection[] collectionArray63 = new java.util.Collection[2];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray64 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray63;
        strComparableCollectionArray64[0] = strComparableCollection50;
        strComparableCollectionArray64[1] = strComparableCollection56;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray69 = strComparableCollection48.toArray(strComparableCollectionArray64);
        java.lang.Class<?> wildcardClass70 = strComparableCollectionArray69.getClass();
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection71 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str72 = strComparableCollection71.toString();
        java.lang.Object[] objArray73 = strComparableCollection71.toArray();
        java.util.Collection[] collectionArray75 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray76 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray75;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray77 = strComparableCollection71.toArray(strComparableCollectionArray76);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator78 = strComparableCollection71.spliterator();
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet79 = strComparableCollection71.uniqueSet();
        java.lang.Class<?> wildcardClass80 = strComparableCollection71.getClass();
        java.lang.reflect.Type[] typeArray81 = new java.lang.reflect.Type[] { wildcardClass34, wildcardClass47, wildcardClass70, wildcardClass80 };
        java.lang.reflect.Type[][] typeArray82 = new java.lang.reflect.Type[][] { typeArray81 };
        java.lang.reflect.Type[][] typeArray83 = strComparableCollection6.toArray(typeArray82);
        int int84 = strComparableCollection6.size();
        boolean boolean85 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection6);
        // The following exception was thrown during execution in test generation
        try {
            int int88 = strComparableCollection0.setCount((java.lang.Comparable<java.lang.String>) "", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "[]" + "'", str12, "[]");
        org.junit.Assert.assertNotNull(strComparableItor13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(strComparableSpliterator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray30), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray30), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray43), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray43), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strComparableEntrySet46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertEquals("'" + str49 + "' != '" + "[]" + "'", str49, "[]");
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertEquals("'" + str61 + "' != '" + "[]" + "'", str61, "[]");
        org.junit.Assert.assertNotNull(collectionArray63);
        org.junit.Assert.assertNotNull(strComparableCollectionArray64);
        org.junit.Assert.assertNotNull(strComparableCollectionArray69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertEquals("'" + str72 + "' != '" + "[]" + "'", str72, "[]");
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray73), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray73), "[]");
        org.junit.Assert.assertNotNull(collectionArray75);
        org.junit.Assert.assertNotNull(strComparableCollectionArray76);
        org.junit.Assert.assertNotNull(strComparableCollectionArray77);
        org.junit.Assert.assertNotNull(strComparableSpliterator78);
        org.junit.Assert.assertNotNull(strComparableSet79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(typeArray81);
        org.junit.Assert.assertNotNull(typeArray82);
        org.junit.Assert.assertNotNull(typeArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        java.lang.String str1 = strComparableCollection0.toString();
        java.lang.Object[] objArray2 = strComparableCollection0.toArray();
        java.util.Collection[] collectionArray4 = new java.util.Collection[0];
        @SuppressWarnings("unchecked")
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray5 = (java.util.Collection<java.lang.Comparable<java.lang.String>>[]) collectionArray4;
        java.util.Collection<java.lang.Comparable<java.lang.String>>[] strComparableCollectionArray6 = strComparableCollection0.toArray(strComparableCollectionArray5);
        java.util.Iterator<java.lang.Comparable<java.lang.String>> strComparableItor7 = strComparableCollection0.iterator();
        java.util.Set<org.apache.commons.collections4.MultiSet.Entry<java.lang.Comparable<java.lang.String>>> strComparableEntrySet8 = strComparableCollection0.entrySet();
        // The following exception was thrown during execution in test generation
        try {
            strComparableCollection0.clear();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
            // Expected exception.
        }
        org.junit.Assert.assertEquals("'" + str1 + "' != '" + "[]" + "'", str1, "[]");
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray2), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray2), "[]");
        org.junit.Assert.assertNotNull(collectionArray4);
        org.junit.Assert.assertNotNull(strComparableCollectionArray5);
        org.junit.Assert.assertNotNull(strComparableCollectionArray6);
        org.junit.Assert.assertNotNull(strComparableItor7);
        org.junit.Assert.assertNotNull(strComparableEntrySet8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection0 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean1 = strComparableCollection0.isEmpty();
        boolean boolean3 = strComparableCollection0.contains((java.lang.Object) 1);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection4 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean5 = strComparableCollection4.isEmpty();
        boolean boolean7 = strComparableCollection4.equals((java.lang.Object) 1.0d);
        boolean boolean9 = strComparableCollection4.contains((java.lang.Object) 100.0f);
        br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>> strComparableCollection10 = new br.com.unicamp.mo409.UnmodifiableMultiSet<java.lang.Comparable<java.lang.String>>();
        boolean boolean11 = strComparableCollection10.isEmpty();
        java.lang.Object[] objArray12 = strComparableCollection10.toArray();
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator13 = strComparableCollection10.spliterator();
        boolean boolean14 = strComparableCollection4.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection10);
        int int15 = strComparableCollection4.size();
        java.lang.String str16 = strComparableCollection4.toString();
        java.lang.Object[] objArray17 = strComparableCollection4.toArray();
        boolean boolean18 = strComparableCollection0.containsAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection4);
        java.util.Spliterator<java.lang.Comparable<java.lang.String>> strComparableSpliterator19 = strComparableCollection0.spliterator();
        java.util.stream.Stream<java.lang.Comparable<java.lang.String>> strComparableStream20 = strComparableCollection0.parallelStream();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray12), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray12), "[]");
        org.junit.Assert.assertNotNull(strComparableSpliterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "[]" + "'", str16, "[]");
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray17), "[]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray17), "[]");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(strComparableSpliterator19);
        org.junit.Assert.assertNotNull(strComparableStream20);
    }
}

